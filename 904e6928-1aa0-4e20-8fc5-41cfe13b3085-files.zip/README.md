# Système de Redirection NFC Vivokey Spark 2

Ce projet fournit tous les éléments nécessaires pour configurer un système qui collecte des informations de contact, la date, l'heure et la localisation lorsque quelqu'un scanne votre puce NFC Vivokey Spark 2, puis redirige automatiquement vers votre site personnel.

## Table des matières

1. [Vue d'ensemble](#vue-densemble)
2. [Composants du système](#composants-du-système)
3. [Configuration et installation](#configuration-et-installation)
4. [Programmation de la puce NFC](#programmation-de-la-puce-nfc)
5. [Personnalisation](#personnalisation)
6. [Sécurité et confidentialité](#sécurité-et-confidentialité)
7. [Dépannage](#dépannage)
8. [Ressources supplémentaires](#ressources-supplémentaires)

## Vue d'ensemble

Ce système permet :
- De collecter les informations de contact des personnes qui scannent votre puce NFC
- D'enregistrer automatiquement la date, l'heure et la localisation du scan
- De rediriger la personne vers votre site web personnel après la collecte d'informations

## Composants du système

1. **Puce Vivokey Spark 2** - Implant NFC programmable
2. **Page de collecte intermédiaire** - Page web qui collecte les informations
3. **Base de données** - Stocke les informations collectées
4. **Mécanisme de redirection** - Redirige l'utilisateur vers votre site personnel

## Configuration et installation

### Prérequis

- Hébergement web avec support PHP (version 7.0 ou supérieure)
- Base de données MySQL/MariaDB
- Accès FTP ou similaire à votre hébergement
- Puce Vivokey Spark 2 implantée
- Smartphone compatible NFC (pour la programmation)

### Installation

1. **Configuration de la base de données**

   - Importez le fichier `database_setup.sql` dans votre serveur MySQL
   - Ou exécutez les commandes SQL manuellement pour créer la base de données et la table

2. **Configuration des fichiers de code**

   - Modifiez `process.php` pour mettre à jour les informations de connexion à la base de données:
     - `$db_host` - L'hôte de votre base de données (généralement 'localhost')
     - `$db_name` - Le nom de votre base de données ('nfc_data' par défaut)
     - `$db_user` - Votre nom d'utilisateur de base de données
     - `$db_pass` - Votre mot de passe de base de données
   - Mettez à jour l'URL de redirection dans `process.php` :
     - `$personal_website_url` - L'URL de votre site personnel

3. **Mise en ligne des fichiers**

   - Téléchargez les fichiers `collection_page_code.html` (renommez-le en `index.html`) et `process.php` sur votre serveur web
   - Placez-les dans un dossier dédié (ex: `/nfc/` ou `/scan/`)

## Programmation de la puce NFC

Suivez les instructions détaillées dans le fichier `nfc_programming_guide.md` pour programmer votre puce Vivokey Spark 2 avec l'URL de votre page de collecte.

En résumé:
1. Installez une application de programmation NFC sur votre smartphone
2. Lancez l'application et choisissez d'écrire une URL
3. Entrez l'URL complète de votre page de collecte (ex: `https://votre-domaine.com/nfc/`)
4. Placez votre téléphone près de votre puce pour écrire les données

## Personnalisation

Vous pouvez personnaliser plusieurs aspects du système:

1. **Apparence de la page de collecte**
   - Modifiez le HTML/CSS dans `collection_page_code.html`
   - Changez les textes, couleurs, et mise en page selon vos préférences

2. **Informations collectées**
   - Ajoutez ou supprimez des champs dans le formulaire HTML
   - Mettez à jour le script PHP pour traiter les nouveaux champs

3. **Comportement de redirection**
   - Ajustez le délai de redirection dans le JavaScript
   - Modifiez le message affiché avant la redirection

## Sécurité et confidentialité

1. **Sécurité de la base de données**
   - Utilisez un utilisateur de base de données avec des privilèges limités
   - Mettez en place des sauvegardes régulières

2. **Protection des données**
   - Assurez-vous que votre site utilise HTTPS
   - Considérez le chiffrement des données sensibles dans la base de données

3. **Conformité RGPD**
   - Ajoutez une mention de politique de confidentialité
   - Permettez aux utilisateurs de demander la suppression de leurs données

## Dépannage

Consultez le document `testing_and_optimization.md` pour des conseils sur la résolution des problèmes courants.

Problèmes fréquents:
- La puce NFC ne se programme pas correctement
- Les données ne sont pas enregistrées dans la base de données
- La géolocalisation ne fonctionne pas
- La redirection ne se produit pas

## Ressources supplémentaires

- Documentation complète de la puce Vivokey Spark 2 dans `vivokey_spark2_research.md`
- Détails sur le mécanisme de redirection dans `redirect_mechanism.md`
- Informations sur la configuration de la base de données dans `database_setup.md`
- Guide de tests et d'optimisation dans `testing_and_optimization.md`

---

Pour toute question ou assistance supplémentaire, consultez la documentation détaillée incluse dans ce package.