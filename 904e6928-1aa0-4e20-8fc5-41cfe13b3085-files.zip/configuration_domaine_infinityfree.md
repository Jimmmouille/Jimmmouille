# Configuration de votre nom de domaine sur InfinityFree

Ce guide vous explique comment configurer votre nom de domaine existant avec un hébergement InfinityFree, ce qui vous permettra d'héberger gratuitement votre page de collecte de données pour votre puce Vivokey Spark 2.

## Étape 1: Créer un compte sur InfinityFree

1. Accédez au site d'[InfinityFree](https://www.infinityfree.com/)
2. Cliquez sur "Sign Up" (S'inscrire)
3. Remplissez le formulaire avec votre adresse email et un mot de passe
4. Validez votre adresse email en cliquant sur le lien dans l'email de confirmation

## Étape 2: Créer un compte d'hébergement

1. Connectez-vous à votre compte InfinityFree
2. Cliquez sur "New Account" (Nouveau compte)
3. Choisissez un nom de compte (ce sera utilisé uniquement pour l'identification interne)
4. Pour le domaine, vous avez deux options:
   - Utiliser temporairement un sous-domaine gratuit d'InfinityFree (par exemple, `votresite.infinityfreeapp.com`)
   - Utiliser directement votre propre domaine (ce que nous ferons dans les étapes suivantes)
5. Si vous choisissez d'utiliser temporairement un sous-domaine gratuit, sélectionnez une option dans la liste déroulante
6. Cliquez sur "Create Account" (Créer un compte)

## Étape 3: Accéder au panneau de contrôle

1. Une fois le compte créé, cliquez sur le nom de votre compte dans la liste
2. Vous serez redirigé vers le panneau de contrôle IfastNet (le fournisseur derrière InfinityFree)
3. Connectez-vous avec les identifiants qui vous ont été fournis par email (différents de vos identifiants InfinityFree)

## Étape 4: Ajouter votre domaine

1. Dans le panneau de contrôle (cPanel), recherchez la section "Domains" (Domaines)
2. Cliquez sur "Add Domain" (Ajouter un domaine)
3. Entrez votre nom de domaine complet (par exemple, `votredomaine.com`) ou un sous-domaine (par exemple, `nfc.votredomaine.com`)
4. Laissez le champ "Document Root" (Racine du document) tel quel
5. Cliquez sur "Add Domain" (Ajouter un domaine)

## Étape 5: Configurer les enregistrements DNS chez votre registrar

Pour que votre domaine pointe vers InfinityFree, vous devez configurer les enregistrements DNS chez votre registrar (l'endroit où vous avez acheté votre nom de domaine).

### Option A: Utiliser tout votre domaine avec InfinityFree

Si vous souhaitez utiliser l'ensemble de votre domaine avec InfinityFree:

1. Connectez-vous au panneau de gestion de votre registrar
2. Localisez la section de gestion des DNS ou des serveurs de noms
3. Remplacez les serveurs de noms actuels par ceux d'InfinityFree:
   - `ns1.ifastnet.com`
   - `ns2.ifastnet.com`
4. Enregistrez les modifications

**Note**: Cette approche transfère le contrôle complet des DNS de votre domaine à InfinityFree. Utilisez cette option uniquement si vous n'utilisez pas déjà votre domaine pour d'autres services (comme un site web existant, des emails, etc.).

### Option B: Utiliser un sous-domaine (recommandé)

Si vous souhaitez utiliser uniquement un sous-domaine (comme `nfc.votredomaine.com`) pour votre page de collecte:

1. Connectez-vous au panneau de gestion de votre registrar
2. Accédez à la section de gestion des DNS
3. Ajoutez un enregistrement de type A pointant votre sous-domaine vers l'adresse IP d'InfinityFree:
   - Type: A
   - Nom/Host: `nfc` (ou le sous-domaine de votre choix)
   - Valeur/Cible: `185.27.134.11` (adresse IP principale d'InfinityFree)
4. Enregistrez les modifications

Vous pouvez également ajouter un second enregistrement A avec la même adresse IP comme sauvegarde:
   - Type: A
   - Nom/Host: `nfc` (ou le sous-domaine de votre choix)
   - Valeur/Cible: `185.27.134.46` (adresse IP secondaire d'InfinityFree)

## Étape 6: Vérifier la propagation DNS

1. Les modifications DNS peuvent prendre de 30 minutes à 48 heures pour se propager complètement
2. Vous pouvez vérifier la propagation en utilisant des outils comme [whatsmydns.net](https://www.whatsmydns.net/)
3. Entrez votre domaine ou sous-domaine et sélectionnez le type d'enregistrement A pour vérifier

## Étape 7: Configurer la zone DNS dans InfinityFree (si nécessaire)

Si vous avez choisi l'option A (remplacement des serveurs de noms):

1. Dans le panneau de contrôle d'InfinityFree, accédez à la section "DNS Functions" (Fonctions DNS)
2. Cliquez sur "DNS Management" (Gestion DNS)
3. Assurez-vous que les enregistrements A pour votre domaine pointent vers les adresses IP d'InfinityFree
4. Si vous souhaitez configurer des sous-domaines supplémentaires, vous pouvez les ajouter ici

## Étape 8: Configurer un certificat SSL (HTTPS)

Pour sécuriser votre site avec HTTPS (recommandé):

1. Dans le panneau de contrôle d'InfinityFree, recherchez "SSL/TLS"
2. Cliquez sur "SSL/TLS Status"
3. Cliquez sur "Manage SSL Sites"
4. Sélectionnez votre domaine dans la liste déroulante
5. Cliquez sur "Install SSL on This Domain"
6. Le certificat Let's Encrypt sera installé automatiquement
7. Une fois terminé, votre site sera accessible via HTTPS

## Étape 9: Télécharger les fichiers de votre page de collecte

1. Dans le panneau de contrôle, accédez à "File Manager" (Gestionnaire de fichiers)
2. Naviguez jusqu'au dossier `htdocs` ou `public_html`
3. Téléchargez votre fichier `index.html` (la page de collecte) et tout autre fichier nécessaire

Alternativement, vous pouvez utiliser FTP:
1. Dans le panneau de contrôle, recherchez les informations FTP
2. Utilisez un client FTP comme FileZilla pour vous connecter
3. Téléchargez vos fichiers dans le dossier `htdocs` ou `public_html`

## Étape 10: Tester votre configuration

1. Ouvrez votre navigateur et accédez à votre domaine ou sous-domaine
2. Vérifiez que votre page de collecte s'affiche correctement
3. Testez le formulaire pour vous assurer que les données sont collectées
4. Vérifiez que la redirection vers votre site personnel fonctionne

## Dépannage

### Problème: Votre domaine n'est pas accessible

- Vérifiez que vous avez correctement configuré les enregistrements DNS
- Assurez-vous que suffisamment de temps s'est écoulé pour la propagation DNS
- Vérifiez que vous avez correctement ajouté le domaine dans InfinityFree

### Problème: La page affiche une erreur 404

- Vérifiez que vous avez téléchargé le fichier `index.html` dans le bon dossier
- Assurez-vous que le nom du fichier est correct (sensible à la casse)

### Problème: Le certificat SSL ne fonctionne pas

- Assurez-vous que la configuration DNS est correcte
- Patientez jusqu'à 24 heures pour la validation et l'installation complète du certificat

### Problème: Formulaire non fonctionnel

- Vérifiez que votre code HTML est correctement configuré
- Assurez-vous que les permissions des fichiers sont correctes
- Vérifiez les restrictions PHP d'InfinityFree si vous utilisez du code PHP

## Ressources supplémentaires

- [Documentation officielle d'InfinityFree](https://forum.infinityfree.com/docs)
- [Forum d'assistance d'InfinityFree](https://forum.infinityfree.com/)
- [FAQ d'InfinityFree](https://www.infinityfree.com/faq/)