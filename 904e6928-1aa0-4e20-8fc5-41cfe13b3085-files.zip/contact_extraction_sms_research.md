# Recherche sur l'Extraction des Contacts et l'Envoi de SMS via NFC

## Extraction des Contacts

Après recherche approfondie, voici les principales découvertes concernant l'extraction automatique des informations de contact depuis un navigateur web mobile :

### API Contact Picker (Contact Picker API)

L'API Contact Picker est une API JavaScript qui permet aux sites web d'accéder aux contacts d'un appareil mobile, mais avec d'importantes restrictions :

1. **Support limité** :
   - Disponible principalement sur Chrome pour Android
   - Sur iOS Safari, c'est une fonctionnalité expérimentale qui doit être activée manuellement
   
2. **Nécessite une interaction utilisateur explicite** :
   - L'API ne peut pas être invoquée automatiquement
   - L'utilisateur doit cliquer sur un bouton ou interagir d'une autre manière
   
3. **Permissions strictes** :
   - L'utilisateur doit sélectionner manuellement les contacts à partager
   - L'application ne peut pas accéder directement à l'ensemble du carnet d'adresses
   
4. **Fonctionnement de base** :
   ```javascript
   // Vérification si l'API est disponible
   if ('contacts' in navigator && 'ContactsManager' in window) {
     // Fonction de sélection de contact
     async function getContacts() {
       try {
         // Ouverture du sélecteur de contacts
         const contacts = await navigator.contacts.select(
           ['name', 'email', 'tel'],
           {multiple: false}
         );
         
         if (contacts.length > 0) {
           // Utilisation des informations du contact
           const contact = contacts[0];
           const name = contact.name[0] || '';
           const phone = contact.tel[0] || '';
           // etc.
         }
       } catch (err) {
         console.error(err);
       }
     }
   }
   ```

### Limitation Fondamentale

Il n'existe pas de méthode pour extraire automatiquement (sans intervention de l'utilisateur) les informations de contact du téléphone de la personne qui scanne votre puce NFC. Cela est délibérément empêché pour des raisons de sécurité et de confidentialité.

## Envoi de SMS depuis le Navigateur

Pour l'envoi de SMS directement depuis le navigateur, il existe plusieurs approches :

### 1. Protocole URI SMS

La méthode la plus directe et universellement compatible consiste à utiliser le protocole URI `sms:` :

```html
<a href="sms:+33612345678?body=Bonjour%20depuis%20la%20puce%20NFC">Envoyer un SMS</a>
```

Fonctionnement :
- Sur mobile, cela ouvre l'application SMS native avec le numéro et le message pré-remplis
- L'utilisateur doit toujours appuyer sur "Envoyer" manuellement
- Compatibilité :
  - Android : `sms:number?body=message`
  - iOS : `sms:number&body=message` (utilise & au lieu de ?)
  - Pour une compatibilité maximale : `sms:number?body=message&body=message`

### 2. APIs tierces pour SMS

Des services comme Twilio, Vonage (Nexmo), etc. permettent d'envoyer des SMS programmatiquement, mais :
- Ils nécessitent une clé API
- Ces services sont payants
- Ils envoient depuis un numéro fourni par le service, pas depuis le téléphone de l'utilisateur

### 3. Partage via le Web Share API

L'API de partage web permet de partager du contenu via les mécanismes natifs de l'appareil :

```javascript
if (navigator.share) {
  navigator.share({
    title: 'Partage de contact',
    text: 'Voici mes coordonnées: Jean Dupont, +33612345678',
    url: 'https://example.com/contact'
  })
  .then(() => console.log('Partagé avec succès'))
  .catch((error) => console.log('Erreur de partage', error));
}
```

Cette approche permet à l'utilisateur de choisir l'application via laquelle partager (SMS, email, messagerie, etc.).

## Recommandation et Approche Pratique

Compte tenu des limitations techniques et des considérations de confidentialité, voici l'approche recommandée :

1. **Créer une page intermédiaire simple qui** :
   - Demande à l'utilisateur de saisir son nom/prénom (ne peut pas être extrait automatiquement)
   - Obtient la localisation avec son accord (via l'API Geolocation)
   - Enregistre automatiquement la date et l'heure
   
2. **Proposer un bouton pour envoyer un SMS pré-rempli** :
   - Utiliser le protocole URI `sms:` avec votre numéro
   - Inclure dans le corps du message les informations collectées

3. **Exemple de code** :
   ```html
   <button id="sendSmsBtn">Envoyer mes coordonnées par SMS</button>
   
   <script>
   document.getElementById('sendSmsBtn').addEventListener('click', function() {
     const name = document.getElementById('name').value;
     const currentDate = new Date().toLocaleString();
     const locationText = userLocation ? `${userLocation.latitude}, ${userLocation.longitude}` : "Non disponible";
     
     // Création du corps du message
     const messageBody = `Nom: ${name}
     Date: ${currentDate}
     Localisation: ${locationText}`;
     
     // Encodage pour l'URL
     const encodedBody = encodeURIComponent(messageBody);
     
     // Création du lien SMS (compatible iOS et Android)
     const smsLink = `sms:+33612345678?body=${encodedBody}&body=${encodedBody}`;
     
     // Ouverture du lien
     window.location.href = smsLink;
   });
   </script>
   ```

Cette approche est :
- Entièrement gratuite
- Compatible avec la plupart des appareils
- Respectueuse de la vie privée (demande le consentement explicite)
- Simple à mettre en œuvre

Elle nécessite toutefois que l'utilisateur saisisse manuellement son nom et appuie sur le bouton d'envoi du SMS, car les contraintes techniques et de confidentialité ne permettent pas l'automatisation complète de ce processus.