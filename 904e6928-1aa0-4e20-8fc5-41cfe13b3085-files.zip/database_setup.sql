-- SQL script to create the database and table for NFC scan data

-- Create database (if it doesn't exist)
CREATE DATABASE IF NOT EXISTS nfc_data;

-- Use the database
USE nfc_data;

-- Create table for scan entries
CREATE TABLE IF NOT EXISTS scan_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    visitor_name VARCHAR(255) NOT NULL,
    visitor_email VARCHAR(255) NOT NULL,
    visitor_message TEXT,
    scan_date DATETIME NOT NULL,
    location_latitude DECIMAL(10,8),
    location_longitude DECIMAL(11,8),
    location_accuracy FLOAT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create index for faster retrieval
CREATE INDEX idx_scan_date ON scan_entries(scan_date);

-- Create a user with necessary permissions (change username and password)
-- GRANT ALL PRIVILEGES ON nfc_data.* TO 'your_username'@'localhost' IDENTIFIED BY 'your_password';
-- FLUSH PRIVILEGES;

-- Note: Uncomment the above GRANT statement after replacing with your desired username and password
-- For security reasons, consider giving only the necessary privileges:
-- GRANT SELECT, INSERT, UPDATE ON nfc_data.* TO 'your_username'@'localhost' IDENTIFIED BY 'your_password';