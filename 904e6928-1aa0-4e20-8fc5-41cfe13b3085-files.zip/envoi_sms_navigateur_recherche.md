# Méthodes d'envoi de SMS depuis un navigateur mobile

Cette recherche se concentre sur les possibilités d'envoi de SMS directement depuis un navigateur web sur mobile, en particulier dans le cadre d'un site web accessible depuis une puce NFC.

## Schéma d'URI `sms:`

Le schéma d'URI `sms:` est la méthode principale pour initier l'envoi d'un SMS depuis un navigateur web sur un appareil mobile. Ce système est intégré nativement dans les navigateurs mobiles et ne nécessite aucune API ou service tiers.

### Syntaxe de base

```
sms:numérodedestination?body=texte_du_message
```

Où:
- `numérodedestination` est le numéro de téléphone du destinataire (optionnel)
- `body=texte_du_message` est le corps du message, qui doit être URL-encodé

### Variations et spécificités

1. **Avec destinataire et corps de message**:
   ```
   sms:+33612345678?body=Bonjour%20voici%20mon%20message
   ```

2. **Sans destinataire, juste le corps du message**:
   ```
   sms:?body=Bonjour%20voici%20mon%20message
   ```
   Cette syntaxe est particulièrement utile pour notre cas d'usage, car elle permet à l'utilisateur de sélectionner le destinataire directement dans son application de messagerie.

3. **Sans corps de message, juste le destinataire**:
   ```
   sms:+33612345678
   ```

4. **Avec un destinataire vide** (pour iOS):
   ```
   sms://?&body=Bonjour%20voici%20mon%20message
   ```

### Compatibilité par plateforme

#### Android
- Supporte généralement bien la syntaxe complète avec destinataire et corps de message
- Les versions récentes d'Android (8+) peuvent avoir des problèmes sur certains appareils
- La syntaxe sans destinataire (`sms:?body=message`) fonctionne généralement bien

#### iOS (iPhone)
- Versions anciennes d'iOS: supportaient uniquement le numéro de téléphone sans le corps du message
- Versions récentes d'iOS: supportent mieux le corps du message
- Syntaxe préférée: `sms://?&body=message` pour un SMS sans destinataire

#### Windows Phone
- Support limité et variable selon les versions

### Mise en œuvre dans le HTML

```html
<a href="sms:?body=Bonjour%2C%20j%27ai%20scann%C3%A9%20votre%20puce%20NFC%20%C3%A0%20Paris%20le%2021%20mai%202025">Envoyer mes coordonnées par SMS</a>
```

Pour créer un lien dynamique avec des valeurs issues d'un formulaire ou d'une API de géolocalisation:

```javascript
function prepareSMSLink() {
  const name = document.getElementById('name').value;
  const location = document.getElementById('location').value;
  const date = new Date().toLocaleDateString();
  
  const messageText = `Bonjour, je m'appelle ${name}. J'ai scanné votre puce NFC à ${location} le ${date}.`;
  const encodedMessage = encodeURIComponent(messageText);
  
  // Créer le lien SMS
  const smsLink = `sms:?body=${encodedMessage}`;
  
  // Rediriger vers l'application SMS
  window.location.href = smsLink;
}
```

### Limitations importantes

1. **Pas d'envoi automatique**: L'utilisateur doit toujours appuyer manuellement sur "Envoyer" dans son application de messagerie.

2. **Accès de l'application**: Nécessite que l'appareil dispose d'une application SMS par défaut et que le navigateur ait la permission de l'ouvrir.

3. **Compatibilité variable**: Le support peut varier selon le navigateur mobile, la version du système d'exploitation et le fabricant de l'appareil.

4. **Longueur limitée**: Les URL ont des limites de longueur (généralement 2000 caractères), ce qui limite la taille du message précomposé.

5. **Problèmes d'encodage**: Certains caractères spéciaux peuvent poser problème s'ils ne sont pas correctement encodés.

## Alternatives payantes ou nécessitant un serveur

### APIs SMS tierces
Des services comme Twilio, Vonage, MessageBird permettent l'envoi de SMS programmés, mais:
- Ils ne sont pas gratuits
- Nécessitent une infrastructure serveur
- Les messages sont envoyés depuis un numéro fourni par le service, pas depuis le téléphone de l'utilisateur

### Progressive Web Apps (PWA)
Les PWA offrent plus de fonctionnalités, mais:
- Ne permettent toujours pas d'envoyer un SMS sans interaction utilisateur
- Nécessitent une installation et des permissions spécifiques

## Solution recommandée pour notre cas d'usage

Compte tenu des limitations et des exigences de gratuité, la meilleure approche est d'utiliser le schéma d'URI `sms:` avec:

1. Un formulaire simple pour recueillir des informations (nom, prénom, date de naissance, email)
2. L'API de géolocalisation du navigateur pour obtenir la position (avec consentement)
3. La création dynamique d'un lien `sms:?body=` contenant toutes ces informations
4. Une redirection automatique vers l'application SMS de l'utilisateur
5. Une redirection vers le site web personnel après un délai ou un retour à la page

Voici un exemple de code HTML/JavaScript qui met en œuvre cette solution:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Contact Rapide</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        form {
            max-width: 500px;
            margin: 0 auto;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h1>Bonjour!</h1>
    <p>Merci de scanner ma puce NFC. Partagez vos coordonnées pour que je puisse vous contacter.</p>
    
    <form id="contactForm">
        <input type="text" id="name" placeholder="Votre nom" required>
        <input type="text" id="firstName" placeholder="Votre prénom" required>
        <input type="date" id="birthdate" placeholder="Votre date de naissance">
        <input type="email" id="email" placeholder="Votre email">
        <button type="button" onclick="getLocationAndPrepareSMS()">Partager mes coordonnées</button>
    </form>
    
    <div id="status"></div>
    
    <script>
    function getLocationAndPrepareSMS() {
        const name = document.getElementById('name').value;
        const firstName = document.getElementById('firstName').value;
        const birthdate = document.getElementById('birthdate').value;
        const email = document.getElementById('email').value;
        
        if (!name || !firstName) {
            alert("Veuillez saisir au moins votre nom et prénom");
            return;
        }
        
        const currentTime = new Date().toLocaleString();
        const statusDiv = document.getElementById('status');
        statusDiv.innerHTML = "Préparation du message...";
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                // Succès
                function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    const locationText = `${lat}, ${lng}`;
                    
                    // Construire le message avec toutes les informations
                    let smsBody = `Bonjour, je m'appelle ${firstName} ${name}.`;
                    
                    if (birthdate) {
                        smsBody += ` Ma date de naissance est le ${birthdate}.`;
                    }
                    
                    if (email) {
                        smsBody += ` Mon email est ${email}.`;
                    }
                    
                    smsBody += ` J'ai scanné votre puce NFC à la position: ${locationText} le ${currentTime}`;
                    
                    // Créer le lien SMS avec iOS fallback
                    // Pour une meilleure compatibilité, on utilise la syntaxe sans destinataire
                    const smsLink = `sms://?&body=${encodeURIComponent(smsBody)}`;
                    
                    statusDiv.innerHTML = "Ouverture de l'application SMS...";
                    
                    // Ouvrir l'application SMS
                    window.location.href = smsLink;
                    
                    // Rediriger vers le site personnel après 5 secondes
                    setTimeout(function() {
                        statusDiv.innerHTML = "Redirection vers le site principal...";
                        window.location.href = "https://votre-site-personnel.com";
                    }, 5000);
                },
                // Erreur
                function(error) {
                    // En cas d'erreur de géolocalisation
                    let smsBody = `Bonjour, je m'appelle ${firstName} ${name}.`;
                    
                    if (birthdate) {
                        smsBody += ` Ma date de naissance est le ${birthdate}.`;
                    }
                    
                    if (email) {
                        smsBody += ` Mon email est ${email}.`;
                    }
                    
                    smsBody += ` J'ai scanné votre puce NFC le ${currentTime}`;
                    
                    const smsLink = `sms://?&body=${encodeURIComponent(smsBody)}`;
                    
                    statusDiv.innerHTML = "Ouverture de l'application SMS...";
                    window.location.href = smsLink;
                    
                    // Rediriger vers le site personnel après 5 secondes
                    setTimeout(function() {
                        statusDiv.innerHTML = "Redirection vers le site principal...";
                        window.location.href = "https://votre-site-personnel.com";
                    }, 5000);
                },
                // Options de géolocalisation
                {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        } else {
            // Si la géolocalisation n'est pas supportée
            let smsBody = `Bonjour, je m'appelle ${firstName} ${name}.`;
            
            if (birthdate) {
                smsBody += ` Ma date de naissance est le ${birthdate}.`;
            }
            
            if (email) {
                smsBody += ` Mon email est ${email}.`;
            }
            
            smsBody += ` J'ai scanné votre puce NFC le ${currentTime}`;
            
            const smsLink = `sms://?&body=${encodeURIComponent(smsBody)}`;
            
            statusDiv.innerHTML = "Ouverture de l'application SMS...";
            window.location.href = smsLink;
            
            // Rediriger vers le site personnel après 5 secondes
            setTimeout(function() {
                statusDiv.innerHTML = "Redirection vers le site principal...";
                window.location.href = "https://votre-site-personnel.com";
            }, 5000);
        }
    }
    </script>
</body>
</html>
```

Cette solution offre:
- Une compatibilité maximale sur iOS et Android
- Une mise en œuvre entièrement gratuite
- L'intégration de toutes les informations demandées
- Un mécanisme de redirection vers le site personnel
- Une gestion des erreurs et des cas où la géolocalisation n'est pas disponible

Malgré ses limitations (nécessité d'une action manuelle pour envoyer le SMS), cette approche représente la meilleure solution pour les contraintes spécifiées.