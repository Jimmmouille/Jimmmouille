# Possibilités d'extraction automatique des contacts depuis un appareil mobile

## Aperçu des technologies disponibles

Les recherches effectuées sur les possibilités d'extraction automatique des contacts depuis un appareil mobile qui scanne une puce NFC révèlent plusieurs limitations importantes, mais aussi quelques solutions potentielles.

## Contact Picker API

### Description générale
Le Contact Picker API est une interface de programmation relativement récente qui permet aux sites web d'accéder à la liste de contacts d'un utilisateur, mais uniquement avec son consentement explicite. Cette API est conçue pour respecter la vie privée des utilisateurs en donnant un contrôle granulaire sur les données partagées.

### Caractéristiques principales
- **Sécurité** : Fonctionne uniquement dans un contexte sécurisé (HTTPS)
- **Déclenchement** : Nécessite une interaction utilisateur (comme un clic sur un bouton)
- **Autorisation** : Demande explicitement la permission à l'utilisateur à chaque utilisation
- **Contrôle granulaire** : L'utilisateur peut choisir quels contacts et quelles informations partager
- **Propriétés accessibles** : Nom, numéro de téléphone, adresse email, adresse postale, photo

### Support par navigateur
- **Chrome pour Android** : Supporté depuis la version 80+
- **Safari iOS** : Non supporté nativement, mais peut être activé via un flag expérimental dans les paramètres avancés
- **Firefox** : Support limité
- **Edge** : Support limité sur mobile

### Exemple d'utilisation
```javascript
// Vérifier si l'API est supportée
if ('contacts' in navigator && 'ContactsManager' in window) {
  // L'API est supportée
  
  // Bouton pour déclencher la sélection des contacts
  document.getElementById('pickContact').addEventListener('click', async () => {
    try {
      // Options pour les propriétés à récupérer
      const props = ['name', 'email', 'tel'];
      const options = { multiple: false };
      
      // Demander à l'utilisateur de sélectionner un contact
      const contacts = await navigator.contacts.select(props, options);
      
      if (contacts.length > 0) {
        // Utiliser les informations du contact sélectionné
        console.log(contacts[0]);
      }
    } catch (err) {
      console.error(err);
    }
  });
}
```

### Limitations
1. **Compatibilité limitée** : Non supporté sur tous les navigateurs/appareils
2. **Interaction utilisateur obligatoire** : Impossible de déclencher automatiquement
3. **Permission temporaire** : L'autorisation doit être accordée à chaque utilisation
4. **Sélection manuelle** : L'utilisateur doit activement sélectionner les contacts à partager

## Alternatives et solutions de contournement

### Formulaire de saisie manuel
La solution la plus universelle reste de proposer un formulaire de saisie où l'utilisateur peut manuellement entrer ses informations de contact.

### Pré-remplissage avec l'API "autocomplete"
Utiliser l'attribut `autocomplete` sur les champs de formulaire peut aider à pré-remplir les informations de l'utilisateur si son navigateur/appareil le supporte.

```html
<input type="text" name="name" autocomplete="name" placeholder="Votre nom">
<input type="email" name="email" autocomplete="email" placeholder="Votre email">
<input type="tel" name="phone" autocomplete="tel" placeholder="Votre téléphone">
```

### Utilisation d'un lien "sms:"
Pour initier l'envoi d'un SMS, on peut utiliser un lien avec le protocole `sms:` qui ouvrira l'application de messagerie de l'appareil.

```html
<a href="sms:+33600000000?body=Bonjour, je viens de scanner votre puce NFC à [LOCATION].">Envoyer par SMS</a>
```

## Conclusion sur l'extraction des contacts

En raison des restrictions de sécurité et de confidentialité sur les appareils mobiles modernes, l'extraction automatique des contacts sans intervention explicite de l'utilisateur n'est pas possible. La meilleure approche serait d'utiliser le Contact Picker API là où il est supporté, avec une solution de repli vers un formulaire manuel pour les autres cas.

Pour le cas spécifique d'une puce NFC qui renvoie vers un site web, il faudra nécessairement que l'utilisateur interagisse avec l'interface pour partager ses informations de contact, que ce soit via l'API de sélection de contacts ou via un formulaire.