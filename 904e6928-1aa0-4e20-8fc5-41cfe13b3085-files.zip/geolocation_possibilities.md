# Possibilités de géolocalisation automatique via le navigateur

## Geolocation API

L'API de géolocalisation du navigateur est la méthode standard pour obtenir la position géographique d'un utilisateur depuis un site web. Elle est largement supportée par les navigateurs modernes et fournit un accès aux coordonnées géographiques de l'appareil.

### Fonctionnement
L'API utilise diverses méthodes pour déterminer la position de l'utilisateur :
- GPS (si disponible sur l'appareil)
- Triangulation des signaux de téléphonie mobile
- Adresses IP
- Points d'accès Wi-Fi à proximité
- Bluetooth (dans certains cas)

### Caractéristiques principales
- **Sécurité** : Fonctionne uniquement dans un contexte sécurisé (HTTPS)
- **Autorisation** : Requiert le consentement explicite de l'utilisateur
- **Précision** : Peut être très précise (10-20 mètres) avec le GPS
- **Options de configuration** : Permet de spécifier la précision souhaitée, le délai maximum, etc.

### Méthodes principales
```javascript
// Obtenir la position actuelle (une seule fois)
navigator.geolocation.getCurrentPosition(successCallback, errorCallback, options);

// Surveiller la position (mise à jour continue)
const watchId = navigator.geolocation.watchPosition(successCallback, errorCallback, options);

// Arrêter la surveillance
navigator.geolocation.clearWatch(watchId);
```

### Exemple d'implémentation
```javascript
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      // Succès
      function(position) {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        const accuracy = position.coords.accuracy; // précision en mètres
        
        console.log(`Position: ${latitude}, ${longitude} (précision: ${accuracy}m)`);
        
        // On peut aussi récupérer l'altitude, la vitesse, etc. si disponibles
        if (position.coords.altitude) {
          console.log(`Altitude: ${position.coords.altitude}m`);
        }
      },
      // Erreur
      function(error) {
        switch(error.code) {
          case error.PERMISSION_DENIED:
            console.error("L'utilisateur a refusé la demande de géolocalisation");
            break;
          case error.POSITION_UNAVAILABLE:
            console.error("Les informations de localisation sont indisponibles");
            break;
          case error.TIMEOUT:
            console.error("La demande de localisation a expiré");
            break;
          case error.UNKNOWN_ERROR:
            console.error("Une erreur inconnue est survenue");
            break;
        }
      },
      // Options
      {
        enableHighAccuracy: true, // demande la meilleure précision possible
        timeout: 5000, // délai maximum en millisecondes
        maximumAge: 0 // n'utilise pas de position mise en cache
      }
    );
  } else {
    console.error("La géolocalisation n'est pas supportée par ce navigateur");
  }
}
```

### Limites et contraintes
1. **Demande de permission** : L'utilisateur doit expressément autoriser le partage de sa position
2. **Pas d'automatisation** : Impossible de déclencher la géolocalisation sans interaction utilisateur
3. **Précision variable** : La précision dépend des capteurs disponibles et de l'environnement
4. **Batterie** : L'utilisation du GPS peut consommer beaucoup de batterie
5. **Contexte** : Ne fonctionne que dans un contexte sécurisé (HTTPS)

## Solutions alternatives

### Géolocalisation par IP
- Moins précise (généralement au niveau de la ville)
- Ne nécessite pas de permission utilisateur
- Plus rapide et moins gourmande en ressources
- Services disponibles : ipinfo.io, ipapi.co, etc.

### Intégration de services cartographiques
Pour une expérience plus riche, on peut utiliser des services comme :
- Google Maps JavaScript API
- Mapbox GL JS
- Leaflet

Ces services permettent d'afficher la position sur une carte et d'offrir des fonctionnalités supplémentaires (itinéraires, points d'intérêt, etc.).

## Solution recommandée pour le cas d'usage

Pour le cas d'un site web accessible depuis une puce NFC qui doit récupérer la position de l'utilisateur :

1. **Demander explicitement l'autorisation de localisation** avec une explication claire de son utilité
2. **Utiliser `getCurrentPosition()` avec un message de fallback** en cas de refus
3. **Convertir les coordonnées en adresse lisible** (géocodage inverse) via un service comme l'API Geocoding de Google Maps
4. **Inclure la position dans le corps du SMS** qui sera envoyé
5. **Prévoir une solution de repli** permettant à l'utilisateur de saisir manuellement sa position

Exemple de bouton déclenchant la géolocalisation et préparant un SMS :
```html
<button onclick="getLocationAndPrepareSMS()">Partager ma position et mes coordonnées</button>

<script>
function getLocationAndPrepareSMS() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      function(position) {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        const locationText = `${lat}, ${lng}`;
        const currentTime = new Date().toLocaleString();
        
        // Créer le lien SMS avec les coordonnées
        const smsBody = `Bonjour, j'ai scanné votre puce NFC à la position: ${locationText} le ${currentTime}`;
        const smsLink = `sms:+33600000000?body=${encodeURIComponent(smsBody)}`;
        
        // Rediriger vers l'application SMS
        window.location.href = smsLink;
      },
      function(error) {
        // En cas d'erreur, proposer une saisie manuelle
        alert("Impossible d'accéder à votre position. Veuillez indiquer manuellement où vous vous trouvez.");
        const manualLocation = prompt("Où vous trouvez-vous?");
        const currentTime = new Date().toLocaleString();
        
        if (manualLocation) {
          const smsBody = `Bonjour, j'ai scanné votre puce NFC à: ${manualLocation} le ${currentTime}`;
          const smsLink = `sms:+33600000000?body=${encodeURIComponent(smsBody)}`;
          window.location.href = smsLink;
        }
      }
    );
  } else {
    alert("La géolocalisation n'est pas supportée par votre navigateur.");
  }
}
</script>
```

Cette solution permet d'obtenir la localisation de l'utilisateur avec son consentement et de l'intégrer facilement dans un SMS, tout en restant entièrement gratuite et ne nécessitant pas d'infrastructure serveur.