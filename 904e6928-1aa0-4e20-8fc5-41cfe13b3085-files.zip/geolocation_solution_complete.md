# Solution complète de géolocalisation automatique

Cette solution explique comment mettre en place une géolocalisation automatique précise lors du scan de votre puce NFC Vivokey Spark 2, tout en gérant les permissions et en offrant une expérience utilisateur optimale.

## 1. Principes de fonctionnement

La géolocalisation dans un navigateur web est régie par plusieurs principes importants :

1. **Sécurité et consentement** : Les navigateurs modernes exigent une autorisation explicite de l'utilisateur pour accéder à sa position.
2. **Contexte sécurisé** : La géolocalisation ne fonctionne que dans un contexte HTTPS (connexion sécurisée).
3. **Interaction utilisateur** : La demande de géolocalisation doit généralement être déclenchée par une action utilisateur.
4. **Précision variable** : La précision dépend du matériel de l'appareil et des conditions environnementales.

## 2. Mise en œuvre technique

### 2.1 L'API Geolocation

L'API Geolocation du navigateur est utilisée pour obtenir les coordonnées géographiques :

```javascript
// Fonction pour obtenir la localisation avec haute précision
function getHighAccuracyLocation() {
    return new Promise((resolve, reject) => {
        if (!navigator.geolocation) {
            reject(new Error("La géolocalisation n'est pas supportée par ce navigateur"));
            return;
        }

        // Options pour une meilleure précision
        const options = {
            enableHighAccuracy: true, // Demande la meilleure précision possible
            timeout: 10000,           // Délai maximum de 10 secondes
            maximumAge: 0             // Force une position fraîche (pas de cache)
        };

        navigator.geolocation.getCurrentPosition(
            // Succès
            (position) => {
                const coordinates = {
                    latitude: position.coords.latitude,
                    longitude: position.coords.longitude,
                    accuracy: position.coords.accuracy, // précision en mètres
                    timestamp: position.timestamp
                };
                
                // Ajouter l'altitude si disponible
                if (position.coords.altitude !== null) {
                    coordinates.altitude = position.coords.altitude;
                }
                
                resolve(coordinates);
            },
            // Erreur
            (error) => {
                let errorMessage;
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMessage = "L'utilisateur a refusé la demande de géolocalisation";
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMessage = "Les informations de localisation sont indisponibles";
                        break;
                    case error.TIMEOUT:
                        errorMessage = "La demande de localisation a expiré";
                        break;
                    default:
                        errorMessage = "Une erreur inconnue est survenue";
                }
                reject(new Error(errorMessage));
            },
            options
        );
    });
}
```

### 2.2 Geocodage inverse (coordonnées → adresse)

Pour obtenir une adresse lisible à partir des coordonnées, nous utiliserons le service gratuit Nominatim d'OpenStreetMap :

```javascript
// Fonction pour convertir des coordonnées en adresse lisible
async function reverseGeocode(latitude, longitude) {
    try {
        // Utilisation de Nominatim (service gratuit d'OpenStreetMap)
        const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`);
        
        if (!response.ok) {
            throw new Error("Erreur lors de la récupération de l'adresse");
        }
        
        const data = await response.json();
        return {
            fullAddress: data.display_name,
            details: data.address
        };
    } catch (error) {
        console.error("Erreur de géocodage inverse:", error);
        return {
            fullAddress: `Coordonnées: ${latitude}, ${longitude}`,
            details: null
        };
    }
}
```

> **Note importante** : Le service Nominatim a des limites d'utilisation strictes. Pour un usage en production, il est recommandé de mettre en place un délai entre les requêtes et de respecter les [conditions d'utilisation](https://operations.osmfoundation.org/policies/nominatim/).

### 2.3 Gestion de l'expérience utilisateur

Pour optimiser l'expérience utilisateur, nous allons :

1. **Demander la permission de manière claire**
2. **Afficher un indicateur de chargement** pendant l'obtention de la position
3. **Gérer les erreurs de manière élégante**
4. **Proposer une alternative** en cas de refus ou d'échec

```javascript
// Interface utilisateur pour la géolocalisation
function setupGeolocationUI() {
    const locationButton = document.getElementById('getLocationButton');
    const locationStatus = document.getElementById('locationStatus');
    
    locationButton.addEventListener('click', async () => {
        locationStatus.textContent = "Obtention de votre position...";
        locationButton.disabled = true;
        
        try {
            // Obtenir les coordonnées
            const coordinates = await getHighAccuracyLocation();
            locationStatus.textContent = `Position obtenue avec une précision de ${Math.round(coordinates.accuracy)} mètres`;
            
            // Convertir en adresse lisible
            locationStatus.textContent = "Conversion des coordonnées en adresse...";
            const addressInfo = await reverseGeocode(coordinates.latitude, coordinates.longitude);
            
            // Générer le lien Google Maps
            const googleMapsLink = `https://maps.google.com/?q=${coordinates.latitude},${coordinates.longitude}`;
            
            // Préparer les données de localisation pour le SMS
            const locationData = {
                coordinates: coordinates,
                address: addressInfo.fullAddress,
                addressDetails: addressInfo.details,
                mapsLink: googleMapsLink
            };
            
            // Stocker pour utilisation ultérieure
            window.locationData = locationData;
            
            // Mise à jour de l'interface
            locationStatus.textContent = `Adresse trouvée : ${addressInfo.fullAddress}`;
            locationButton.textContent = "Position obtenue ✓";
            document.getElementById('submitForm').disabled = false;
            
        } catch (error) {
            locationStatus.textContent = `Erreur : ${error.message}`;
            locationButton.disabled = false;
            locationButton.textContent = "Réessayer";
            
            // Activer quand même le bouton d'envoi du formulaire
            document.getElementById('submitForm').disabled = false;
        }
    });
}
```

## 3. Solution complète intégrée

Voici la solution complète qui intègre la géolocalisation automatique avec le formulaire de contact et l'envoi de SMS :

```html
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact via NFC</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: #f7f9fc;
            color: #333;
            line-height: 1.6;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            padding: 30px;
        }
        h1 {
            color: #2c3e50;
            margin-top: 0;
            text-align: center;
            font-size: 28px;
        }
        .description {
            text-align: center;
            margin-bottom: 30px;
            color: #5d6778;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 6px;
            font-weight: 600;
            color: #2c3e50;
        }
        input, button {
            width: 100%;
            padding: 12px;
            border-radius: 6px;
            box-sizing: border-box;
            border: 1px solid #dce1e9;
            font-size: 16px;
        }
        input:focus {
            border-color: #3498db;
            outline: none;
            box-shadow: 0 0 0 3px rgba(52, 152, 219, 0.2);
        }
        button {
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
            font-weight: 600;
            margin-top: 10px;
            transition: background-color 0.2s;
        }
        button:hover {
            background-color: #2980b9;
        }
        button:disabled {
            background-color: #95a5a6;
            cursor: not-allowed;
        }
        .location-button {
            background-color: #2ecc71;
        }
        .location-button:hover {
            background-color: #27ae60;
        }
        #locationStatus {
            margin-top: 8px;
            font-size: 14px;
            color: #7f8c8d;
            min-height: 40px;
        }
        .privacy-notice {
            font-size: 13px;
            color: #95a5a6;
            text-align: center;
            margin-top: 20px;
        }
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 14px;
            color: #7f8c8d;
        }
        .loader {
            border: 3px solid #f3f3f3;
            border-top: 3px solid #3498db;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
            vertical-align: middle;
            margin-right: 8px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Bonjour !</h1>
        <p class="description">Merci de scanner ma puce NFC. Partagez vos coordonnées pour que je puisse vous recontacter.</p>
        
        <form id="contactForm">
            <div class="form-group">
                <label for="name">Nom</label>
                <input type="text" id="name" placeholder="Votre nom" required>
            </div>
            
            <div class="form-group">
                <label for="firstName">Prénom</label>
                <input type="text" id="firstName" placeholder="Votre prénom" required>
            </div>
            
            <div class="form-group">
                <label for="birthdate">Date de naissance</label>
                <input type="date" id="birthdate">
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" placeholder="Votre email">
            </div>
            
            <div class="form-group">
                <button type="button" id="getLocationButton" class="location-button">Partager ma position</button>
                <div id="locationStatus"></div>
            </div>
            
            <button type="button" id="submitForm" disabled>Envoyer mes coordonnées</button>
        </form>
        
        <p class="privacy-notice">
            Vos informations et votre position ne seront utilisées que pour me permettre de vous recontacter. 
            Aucune donnée n'est stockée sur un serveur.
        </p>
        
        <div class="footer">
            Après l'envoi du message, vous serez redirigé vers <a href="https://www.byjimjoum.com">www.byjimjoum.com</a>
        </div>
    </div>

    <script>
        // Fonction pour obtenir la localisation avec haute précision
        function getHighAccuracyLocation() {
            return new Promise((resolve, reject) => {
                if (!navigator.geolocation) {
                    reject(new Error("La géolocalisation n'est pas supportée par ce navigateur"));
                    return;
                }

                // Options pour une meilleure précision
                const options = {
                    enableHighAccuracy: true, // Demande la meilleure précision possible
                    timeout: 10000,           // Délai maximum de 10 secondes
                    maximumAge: 0             // Force une position fraîche (pas de cache)
                };

                navigator.geolocation.getCurrentPosition(
                    // Succès
                    (position) => {
                        const coordinates = {
                            latitude: position.coords.latitude,
                            longitude: position.coords.longitude,
                            accuracy: position.coords.accuracy, // précision en mètres
                            timestamp: new Date(position.timestamp).toLocaleString()
                        };
                        
                        // Ajouter l'altitude si disponible
                        if (position.coords.altitude !== null) {
                            coordinates.altitude = position.coords.altitude;
                        }
                        
                        resolve(coordinates);
                    },
                    // Erreur
                    (error) => {
                        let errorMessage;
                        switch(error.code) {
                            case error.PERMISSION_DENIED:
                                errorMessage = "L'utilisateur a refusé la demande de géolocalisation";
                                break;
                            case error.POSITION_UNAVAILABLE:
                                errorMessage = "Les informations de localisation sont indisponibles";
                                break;
                            case error.TIMEOUT:
                                errorMessage = "La demande de localisation a expiré";
                                break;
                            default:
                                errorMessage = "Une erreur inconnue est survenue";
                        }
                        reject(new Error(errorMessage));
                    },
                    options
                );
            });
        }

        // Fonction pour convertir des coordonnées en adresse lisible
        async function reverseGeocode(latitude, longitude) {
            try {
                // Utilisation de Nominatim (service gratuit d'OpenStreetMap)
                const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`);
                
                if (!response.ok) {
                    throw new Error("Erreur lors de la récupération de l'adresse");
                }
                
                const data = await response.json();
                return {
                    fullAddress: data.display_name,
                    details: data.address
                };
            } catch (error) {
                console.error("Erreur de géocodage inverse:", error);
                return {
                    fullAddress: `Coordonnées: ${latitude}, ${longitude}`,
                    details: null
                };
            }
        }

        // Configuration initiale
        document.addEventListener('DOMContentLoaded', function() {
            const locationButton = document.getElementById('getLocationButton');
            const locationStatus = document.getElementById('locationStatus');
            const submitButton = document.getElementById('submitForm');
            
            // Configuration du bouton de localisation
            locationButton.addEventListener('click', async () => {
                locationStatus.innerHTML = '<div class="loader"></div> Obtention de votre position...';
                locationButton.disabled = true;
                
                try {
                    // Obtenir les coordonnées
                    const coordinates = await getHighAccuracyLocation();
                    locationStatus.textContent = `Position obtenue avec une précision de ${Math.round(coordinates.accuracy)} mètres`;
                    
                    // Convertir en adresse lisible
                    locationStatus.innerHTML = '<div class="loader"></div> Conversion des coordonnées en adresse...';
                    const addressInfo = await reverseGeocode(coordinates.latitude, coordinates.longitude);
                    
                    // Générer le lien Google Maps
                    const googleMapsLink = `https://maps.google.com/?q=${coordinates.latitude},${coordinates.longitude}`;
                    
                    // Préparer les données de localisation pour le SMS
                    const locationData = {
                        coordinates: coordinates,
                        address: addressInfo.fullAddress,
                        addressDetails: addressInfo.details,
                        mapsLink: googleMapsLink
                    };
                    
                    // Stocker pour utilisation ultérieure
                    window.locationData = locationData;
                    
                    // Mise à jour de l'interface
                    locationStatus.textContent = `Adresse : ${addressInfo.fullAddress}`;
                    locationButton.textContent = "Position obtenue ✓";
                    locationButton.style.backgroundColor = "#27ae60";
                    submitButton.disabled = false;
                    
                } catch (error) {
                    locationStatus.textContent = `Erreur : ${error.message}`;
                    locationButton.disabled = false;
                    locationButton.textContent = "Réessayer";
                    
                    // Activer quand même le bouton d'envoi du formulaire
                    submitButton.disabled = false;
                }
            });
            
            // Configuration du bouton d'envoi
            submitButton.addEventListener('click', () => {
                const name = document.getElementById('name').value;
                const firstName = document.getElementById('firstName').value;
                const birthdate = document.getElementById('birthdate').value;
                const email = document.getElementById('email').value;
                
                if (!name || !firstName) {
                    alert("Veuillez saisir au moins votre nom et prénom");
                    return;
                }
                
                // Construire le message SMS
                let locationText = "Position non disponible";
                let mapsLink = "";
                
                if (window.locationData) {
                    locationText = window.locationData.address;
                    mapsLink = window.locationData.mapsLink;
                }
                
                // Construction du message SMS
                let smsBody = `Contact NFC: ${firstName} ${name}`;
                
                if (birthdate) {
                    smsBody += `, né(e) le ${birthdate}`;
                }
                
                if (email) {
                    smsBody += `, email: ${email}`;
                }
                
                smsBody += `. Localisation: ${locationText}`;
                
                if (mapsLink) {
                    smsBody += `. Maps: ${mapsLink}`;
                }
                
                // Créer le lien SMS avec numéro direct
                const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
                
                // Ouvrir l'application SMS
                window.location.href = smsLink;
                
                // Rediriger vers le site personnel après 3 secondes
                setTimeout(function() {
                    window.location.href = "https://www.byjimjoum.com";
                }, 3000);
            });
        });
    </script>
</body>
</html>
```

## 4. Fonctionnalités avancées

### 4.1 Géolocalisation en continu pour améliorer la précision

Si une précision maximale est requise, vous pouvez utiliser `watchPosition` au lieu de `getCurrentPosition` :

```javascript
const watchId = navigator.geolocation.watchPosition(
    (position) => {
        // Cette fonction est appelée à chaque mise à jour de position
        // Utile pour affiner progressivement la précision
    },
    (error) => {
        // Gestion des erreurs
    },
    { enableHighAccuracy: true, maximumAge: 0 }
);

// N'oubliez pas d'arrêter le suivi quand vous n'en avez plus besoin
navigator.geolocation.clearWatch(watchId);
```

### 4.2 Fallback vers la géolocalisation par IP

En cas d'échec ou de refus de la géolocalisation, vous pouvez utiliser un service de géolocalisation par IP comme solution de repli :

```javascript
async function getLocationByIP() {
    try {
        const response = await fetch('https://ipapi.co/json/');
        const data = await response.json();
        return {
            latitude: data.latitude,
            longitude: data.longitude,
            city: data.city,
            region: data.region,
            country: data.country_name,
            accuracy: 5000 // Précision approximative en mètres (estimation)
        };
    } catch (error) {
        console.error('Erreur lors de la géolocalisation par IP:', error);
        return null;
    }
}
```

Cette méthode est moins précise (généralement au niveau de la ville) mais ne nécessite pas d'autorisation de l'utilisateur.

## 5. Optimisations et considérations

### 5.1 Performance et batterie

La géolocalisation haute précision peut consommer beaucoup de batterie, surtout si le GPS est activé. Il est recommandé de :

1. Demander la position une seule fois plutôt qu'en continu, sauf si nécessaire
2. Utiliser `maximumAge` pour accepter les positions récemment mises en cache
3. Ne pas activer `enableHighAccuracy` si une précision moyenne est suffisante

### 5.2 Confidentialité

La géolocalisation est une donnée sensible. Assurez-vous de :

1. Expliquer clairement à l'utilisateur pourquoi vous demandez sa position
2. Ne pas stocker la position plus longtemps que nécessaire
3. Informer l'utilisateur de l'utilisation qui sera faite de ses données

### 5.3 Compatibilité

Pour assurer une compatibilité maximale :

1. Testez sur différents navigateurs (Chrome, Safari, Firefox) et systèmes (iOS, Android)
2. Prévoyez toujours une solution de repli en cas d'échec ou de refus
3. Utilisez des polyfills pour les navigateurs plus anciens si nécessaire

## 6. Intégration avec la solution existante

La solution de géolocalisation s'intègre parfaitement avec le système d'envoi de SMS direct développé précédemment. Les coordonnées et l'adresse obtenues seront incluses dans le message SMS envoyé à votre numéro, et l'utilisateur sera ensuite redirigé vers votre site web (www.byjimjoum.com).

Cette solution complète offre:
- Une précision maximale pour la géolocalisation
- La conversion des coordonnées en adresse lisible
- Un lien Google Maps pour visualiser facilement l'emplacement
- Une expérience utilisateur intuitive et rassurante
- Une redirection vers votre site web après l'envoi du SMS