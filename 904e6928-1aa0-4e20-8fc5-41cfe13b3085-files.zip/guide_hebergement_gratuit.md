# Guide d'Hébergement Gratuit avec GitHub Pages

Ce guide vous explique comment héberger gratuitement votre page intermédiaire NFC pour la puce Vivokey Spark 2, en utilisant GitHub Pages et votre propre nom de domaine.

## Avantages de GitHub Pages

- **Totalement gratuit** sans limitation de temps
- **HTTPS inclus** automatiquement
- **Facile à mettre à jour** via Git
- **Très fiable** (hébergé par Microsoft)
- **Pas de publicités**
- **Peut utiliser votre propre domaine**

## Étape 1: Créer un compte GitHub

1. Allez sur [GitHub](https://github.com/)
2. Cliquez sur "Sign up" et suivez le processus d'inscription
3. Vérifiez votre adresse email

## Étape 2: Créer un nouveau dépôt (repository)

1. Une fois connecté, cliquez sur le bouton "+" en haut à droite puis "New repository"
2. Nommez votre dépôt `nfc-page` (ou un autre nom de votre choix)
3. Assurez-vous qu'il est défini comme "Public"
4. Cochez "Add a README file"
5. Cliquez sur "Create repository"

## Étape 3: Ajouter votre fichier HTML

1. Dans votre nouveau dépôt, cliquez sur "Add file" puis "Upload files"
2. Glissez-déposez ou sélectionnez le fichier `page_intermediaire_sms.html`
3. Renommez-le en `index.html` (important pour que GitHub Pages reconnaisse votre page d'accueil)
4. Ajoutez un message de commit comme "Ajout de la page d'accueil"
5. Cliquez sur "Commit changes"

## Étape 4: Configurer GitHub Pages

1. Allez dans les "Settings" de votre dépôt (onglet avec l'icône d'engrenage)
2. Dans le menu de gauche, cliquez sur "Pages"
3. Dans la section "Source", sélectionnez "Deploy from a branch"
4. Dans la section "Branch", sélectionnez "main" et le dossier "/" (racine)
5. Cliquez sur "Save"
6. Patientez quelques minutes pendant que GitHub déploie votre site
7. Rafraîchissez la page, vous verrez un message avec l'URL de votre site (généralement `https://votre-nom-utilisateur.github.io/nfc-page/`)

## Étape 5: Configurer votre nom de domaine personnalisé

### Sous-étape 5.1: Configurer dans GitHub Pages

1. Dans les paramètres GitHub Pages de votre dépôt
2. Dans la section "Custom domain", entrez votre domaine ou sous-domaine (par exemple `nfc.votredomaine.com`)
3. Cliquez sur "Save"
4. Cochez "Enforce HTTPS" (cette option pourrait être temporairement désactivée jusqu'à ce que la vérification du domaine soit terminée)

### Sous-étape 5.2: Configurer les DNS chez votre registrar

1. Connectez-vous au panneau de gestion de votre domaine chez votre registrar (OVH, Gandi, Ionos, etc.)
2. Accédez à la section de gestion des enregistrements DNS
3. Si vous utilisez un sous-domaine (recommandé), ajoutez un enregistrement CNAME :
   - Type : CNAME
   - Nom/Hôte : `nfc` (le sous-domaine)
   - Valeur/Destination : `votre-nom-utilisateur.github.io` (sans `https://` et sans `/nfc-page`)
   - TTL : Automatique ou 3600

4. Si vous utilisez le domaine principal, vous devrez ajouter 4 enregistrements A pointant vers les adresses IP de GitHub Pages :
   - Type : A
   - Nom/Hôte : @ (ou laissez vide selon votre registrar)
   - Valeur/Destination : 
     - `185.199.108.153`
     - `185.199.109.153`
     - `185.199.110.153`
     - `185.199.111.153`
   - TTL : Automatique ou 3600

## Étape 6: Personnaliser votre page

### Personnaliser le numéro de téléphone

1. Dans votre dépôt GitHub, cliquez sur le fichier `index.html`
2. Cliquez sur le bouton d'édition (icône de crayon)
3. Recherchez la ligne contenant `const yourPhoneNumber = "+33612345678";`
4. Remplacez le numéro par le vôtre (n'oubliez pas l'indicatif international +33 pour la France)
5. Ajoutez un message de commit comme "Mise à jour du numéro de téléphone"
6. Cliquez sur "Commit changes"

### Personnaliser l'URL de redirection

1. Recherchez dans le fichier la ligne `<a href="https://votre-site-personnel.com" class="redirect-link" id="redirectLink">`
2. Remplacez `https://votre-site-personnel.com` par l'URL de votre site personnel
3. Ajoutez un message de commit
4. Cliquez sur "Commit changes"

## Étape 7: Tester votre site

1. Visitez votre site à l'adresse `https://nfc.votredomaine.com` (ou l'URL GitHub Pages si vous n'avez pas configuré de domaine personnalisé)
2. Vérifiez que :
   - La géolocalisation fonctionne
   - Le bouton d'envoi de SMS ouvre bien l'application SMS avec le message pré-rempli
   - Le lien vers votre site personnel fonctionne correctement

## Étape 8: Programmer votre puce Vivokey Spark 2

1. Utilisez NFC Tools ou une application similaire sur votre smartphone
2. Choisissez d'écrire une URL
3. Entrez l'URL complète de votre site (avec https://)
4. Programmez votre puce en suivant les instructions de l'application

## Dépannage

### La page ne s'affiche pas

- Vérifiez que le fichier est bien nommé `index.html`
- Vérifiez que GitHub Pages est activé et que le site est déployé (dans les paramètres)
- Si vous utilisez un domaine personnalisé, vérifiez que les DNS sont correctement configurés

### Les DNS ne se propagent pas

- La propagation DNS peut prendre jusqu'à 48h
- Vérifiez vos enregistrements DNS avec un outil comme [DNSChecker](https://dnschecker.org/)

### Le bouton SMS ne fonctionne pas

- Vérifiez que vous avez bien saisi votre numéro de téléphone avec l'indicatif international
- Testez sur différents appareils (Android et iOS si possible)

## Ressources supplémentaires

- [Documentation officielle GitHub Pages](https://docs.github.com/en/pages)
- [Dépannage GitHub Pages](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/troubleshooting-custom-domains-and-github-pages)
- [Guide de configuration DNS pour différents registrars](https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site)