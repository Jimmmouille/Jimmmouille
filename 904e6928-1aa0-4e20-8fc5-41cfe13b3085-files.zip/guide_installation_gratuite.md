# Guide d'Installation Gratuite

Ce guide vous explique comment mettre en place un système de collecte d'informations et de redirection pour votre puce Vivokey Spark 2, en utilisant uniquement des services gratuits.

## Table des matières

1. [Création d'un formulaire Google](#création-dun-formulaire-google)
2. [Configuration de la page de collecte](#configuration-de-la-page-de-collecte)
3. [Hébergement sur GitHub Pages](#hébergement-sur-github-pages)
4. [Configuration de votre domaine](#configuration-de-votre-domaine)
5. [Programmation de la puce NFC](#programmation-de-la-puce-nfc)
6. [Test du système complet](#test-du-système-complet)

## Création d'un formulaire Google

1. **Créez un nouveau formulaire Google**
   - Accédez à [Google Forms](https://forms.google.com)
   - Créez un nouveau formulaire
   - Ajoutez les champs suivants:
     - Nom (Réponse courte, obligatoire)
     - Email (Réponse courte, obligatoire)
     - Message (Paragraphe, facultatif)
     - Latitude (Réponse courte, masqué)
     - Longitude (Réponse courte, masqué)
     - Date et heure du scan (Réponse courte, masqué)

2. **Configurez les paramètres du formulaire**
   - Cliquez sur l'icône ⚙️ (Paramètres)
   - Dans l'onglet "Général", cochez "Collecter les adresses e-mail"
   - Dans l'onglet "Réponses", activez "Recevoir une notification par e-mail pour les nouvelles réponses"

3. **Récupérez les identifiants du formulaire**
   - Cliquez sur "Envoyer" puis sur l'icône </>
   - Copiez l'URL du formulaire
   - Notez l'ID du formulaire (la partie entre "formResponse" et "viewform" dans l'URL)
   - Ouvrez l'outil d'inspection de votre navigateur (F12) et examinez le code source du formulaire
   - Notez les identifiants de chaque champ (entry.XXXXXX)

## Configuration de la page de collecte

1. **Modifiez le fichier HTML**
   - Ouvrez le fichier `simple_data_collection.html` fourni
   - Remplacez `YOUR_FORM_ID` par l'ID de votre formulaire Google
   - Remplacez chaque `entry.XXXXXX` par les identifiants correspondants de vos champs
   - Modifiez `https://votre-site-personnel.com` par l'URL de votre site web personnel

2. **Personnalisez l'apparence (optionnel)**
   - Modifiez les couleurs dans les variables CSS (section `:root`)
   - Modifiez les textes selon vos préférences
   - Ajoutez votre logo ou d'autres éléments visuels

## Hébergement sur GitHub Pages

1. **Créez un compte GitHub**
   - Si vous n'en avez pas déjà un, créez un compte sur [GitHub](https://github.com)

2. **Créez un nouveau dépôt**
   - Cliquez sur "New repository"
   - Nommez-le `nfc-redirect` ou un nom similaire
   - Assurez-vous qu'il est public
   - Initialisez avec un README

3. **Téléchargez vos fichiers**
   - Cliquez sur "Add file" > "Upload files"
   - Glissez-déposez le fichier `simple_data_collection.html` (renommez-le en `index.html`)
   - Ajoutez un message de commit et cliquez sur "Commit changes"

4. **Activez GitHub Pages**
   - Allez dans "Settings" > "Pages"
   - Dans la section "Source", sélectionnez "main" comme branche et "/" comme dossier
   - Cliquez sur "Save"
   - Attendez quelques minutes pour que votre site soit déployé
   - Notez l'URL de votre site (généralement `https://votre-nom.github.io/nfc-redirect`)

## Configuration de votre domaine

### Option 1: Utiliser un sous-domaine de votre domaine existant

1. **Créez un sous-domaine**
   - Accédez au panneau de gestion DNS de votre registrar
   - Créez un sous-domaine (par exemple, `nfc.votredomaine.com`)
   - Ajoutez un enregistrement CNAME pointant vers `votre-nom.github.io`

2. **Configurez GitHub Pages pour utiliser votre domaine**
   - Dans les paramètres GitHub Pages, sous "Custom domain"
   - Entrez votre sous-domaine (`nfc.votredomaine.com`)
   - Cochez "Enforce HTTPS" (une fois que les vérifications DNS sont terminées)

### Option 2: Utiliser un hébergeur web gratuit

Si vous préférez ne pas utiliser GitHub Pages, vous pouvez opter pour un hébergeur gratuit:

1. **Créez un compte chez InfinityFree**
   - Inscrivez-vous sur [InfinityFree](https://www.infinityfree.com/)
   - Créez un nouveau compte d'hébergement
   - Utilisez votre domaine ou choisissez un sous-domaine gratuit

2. **Téléchargez vos fichiers**
   - Utilisez le gestionnaire de fichiers ou FTP pour télécharger votre fichier HTML
   - Renommez-le en `index.html` s'il ne l'est pas déjà

3. **Configurez les DNS**
   - Suivez les instructions d'InfinityFree pour pointer votre domaine ou sous-domaine vers leur serveur

## Programmation de la puce NFC

1. **Installez une application NFC**
   - Sur Android: [NFC Tools](https://play.google.com/store/apps/details?id=com.wakdev.wdnfc)
   - Sur iOS: [NFC Tools](https://apps.apple.com/app/nfc-tools/id1252962749)

2. **Programmez la puce**
   - Ouvrez l'application NFC Tools
   - Appuyez sur l'onglet "Écrire"
   - Choisissez "Ajouter un enregistrement" puis "URL/URI"
   - Entrez l'URL complète de votre page de collecte (`https://nfc.votredomaine.com` ou l'URL GitHub Pages)
   - Appuyez sur "Ok" puis "Écrire"
   - Approchez votre téléphone de votre puce Vivokey Spark 2 implantée
   - Maintenez jusqu'à ce que l'écriture soit confirmée

## Test du système complet

1. **Vérification de la programmation**
   - Utilisez un autre téléphone pour scanner votre puce
   - Vérifiez que la page de collecte s'ouvre correctement

2. **Test du formulaire**
   - Remplissez et soumettez le formulaire
   - Vérifiez que vous êtes redirigé vers votre site personnel
   - Vérifiez que les données sont bien enregistrées dans Google Sheets (liée à votre formulaire)

3. **Vérification des données stockées**
   - Accédez à Google Forms > votre formulaire > "Réponses" pour voir les données collectées
   - Vérifiez que la géolocalisation, la date et l'heure sont correctement enregistrées

## Maintenance et suivi

- Vérifiez régulièrement les réponses dans Google Forms
- Vous pouvez exporter les données vers Google Sheets pour une analyse plus approfondie
- Si vous atteignez les limites de Google Forms, envisagez de créer un nouveau formulaire
- Les données sont également stockées en local dans le navigateur de l'utilisateur (localStorage), mais vous n'y avez pas accès directement

## Ressources supplémentaires

- [Documentation de Google Forms](https://support.google.com/docs/answer/6281888)
- [Documentation de GitHub Pages](https://docs.github.com/en/pages)
- [Documentation NFC Tools](https://www.wakdev.com/en/apps/nfc-tools.html)