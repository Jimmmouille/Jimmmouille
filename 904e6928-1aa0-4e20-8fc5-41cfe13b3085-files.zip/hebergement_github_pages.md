# Guide d'hébergement gratuit sur GitHub Pages avec un nom de domaine personnalisé

Ce guide détaillé vous explique comment héberger gratuitement votre page intermédiaire sur GitHub Pages tout en utilisant votre nom de domaine existant (byjimjoum.com).

## Pourquoi GitHub Pages ?

GitHub Pages est une solution d'hébergement gratuite proposée par GitHub qui permet de publier facilement des sites web statiques. Voici ses avantages :

- **Totalement gratuit** sans limitation de temps
- **HTTPS automatique et gratuit** avec certificat SSL fourni
- **Fiabilité** de l'infrastructure GitHub (haute disponibilité)
- **Simplicité** de déploiement et de mise à jour
- **Support des noms de domaine personnalisés**
- **Pas de publicité** ni de limitations gênantes

## Prérequis

- Un compte GitHub
- Accès aux paramètres DNS de votre domaine byjimjoum.com
- Votre page HTML intermédiaire (déjà créée)

## Étape 1 : Créer un dépôt GitHub

1. Connectez-vous à votre compte GitHub ou créez-en un sur [github.com](https://github.com/)
2. Créez un nouveau dépôt nommé **exactement** : `votre-nom-utilisateur.github.io` en remplaçant "votre-nom-utilisateur" par votre nom d'utilisateur GitHub
3. Ce format spécial de nom est requis pour les sites GitHub Pages d'utilisateur

![Création d'un dépôt GitHub](https://docs.github.com/assets/cb-25535/images/help/repository/create-repository-name.png)

## Étape 2 : Ajouter votre page intermédiaire au dépôt

1. Clonez le dépôt sur votre ordinateur ou utilisez l'interface web de GitHub
2. Ajoutez votre fichier HTML sous le nom `index.html` à la racine du dépôt
3. Committez et poussez les changements

Si vous utilisez l'interface web :
- Cliquez sur "Add file" > "Create new file"
- Nommez-le `index.html`
- Copiez-collez tout le code de votre page intermédiaire
- Cliquez sur "Commit new file"

## Étape 3 : Activer GitHub Pages

1. Dans votre dépôt GitHub, allez dans "Settings" (Paramètres)
2. Faites défiler jusqu'à la section "GitHub Pages"
3. Sous "Source", sélectionnez la branche principale (généralement "main" ou "master")
4. Cliquez sur "Save"

GitHub déploiera automatiquement votre site à l'adresse `https://votre-nom-utilisateur.github.io/`

## Étape 4 : Configurer votre nom de domaine personnalisé dans GitHub

1. Toujours dans la section "GitHub Pages" des paramètres, trouvez "Custom domain"
2. Entrez votre domaine : `byjimjoum.com`
3. Cliquez sur "Save"
4. **Important** : Cochez la case "Enforce HTTPS" une fois que le domaine sera vérifié (cela peut prendre quelques minutes à quelques heures)

Cette action créera un fichier CNAME dans votre dépôt, qui indique à GitHub Pages quel domaine utiliser.

## Étape 5 : Configurer les paramètres DNS de votre domaine

Pour que votre domaine `byjimjoum.com` pointe vers votre site GitHub Pages, vous devez configurer les enregistrements DNS chez votre fournisseur de domaine.

### Pour le domaine apex (byjimjoum.com)

Ajoutez **quatre** enregistrements A pointant vers les adresses IP de GitHub Pages :

| Type | Nom/Hôte | Valeur             | TTL     |
|------|----------|-------------------|---------|
| A    | @        | 185.199.108.153   | 1 heure |
| A    | @        | 185.199.109.153   | 1 heure |
| A    | @        | 185.199.110.153   | 1 heure |
| A    | @        | 185.199.111.153   | 1 heure |

### Pour le sous-domaine www (www.byjimjoum.com)

Ajoutez un enregistrement CNAME :

| Type  | Nom/Hôte | Valeur                         | TTL     |
|-------|----------|-------------------------------|---------|
| CNAME | www      | votre-nom-utilisateur.github.io | 1 heure |

## Étape 6 : Vérifier la propagation DNS

Les changements DNS peuvent prendre jusqu'à 24 heures pour se propager, mais généralement cela prend entre 15 minutes et quelques heures.

Pour vérifier si les changements ont été propagés, vous pouvez utiliser un outil de ligne de commande :

```bash
dig byjimjoum.com +noall +answer
```

Ou utilisez un service en ligne comme [dnschecker.org](https://dnschecker.org/).

## Étape 7 : Vérifier que tout fonctionne

1. Visitez votre domaine personnalisé (byjimjoum.com) dans un navigateur
2. Vérifiez que votre page intermédiaire s'affiche correctement
3. Vérifiez que la connexion est sécurisée (HTTPS) en cherchant le cadenas dans la barre d'adresse

## Dépannage

### Le site ne s'affiche pas ou affiche une erreur 404

- Vérifiez que le fichier `index.html` est bien à la racine de votre dépôt
- Assurez-vous que GitHub Pages est activé dans les paramètres
- Vérifiez que les enregistrements DNS sont correctement configurés

### Site non sécurisé (pas de HTTPS)

- Assurez-vous que l'option "Enforce HTTPS" est activée dans les paramètres GitHub Pages
- Attendez quelques heures pour que GitHub émette et configure le certificat SSL

### Erreur "Domain Not Found"

- Vérifiez que le nom de domaine est correctement entré dans les paramètres GitHub
- Assurez-vous que les enregistrements DNS pointent vers les bonnes adresses IP de GitHub

### Nom de domaine vérifié mais site non accessible

- Vérifiez que la propagation DNS est terminée
- Assurez-vous qu'il n'y a pas de redirection configurée chez votre fournisseur de domaine

## Conseils supplémentaires

- **Conservez vos fichiers HTML, CSS et JavaScript dans des fichiers séparés** pour une meilleure organisation
- **Minimisez vos fichiers** pour accélérer le chargement
- **Testez sur différents appareils et navigateurs** pour vous assurer que tout fonctionne correctement
- **Utilisez le cache du navigateur** à votre avantage en définissant les bons en-têtes

## Maintenance

Une fois configuré, votre site sera automatiquement mis à jour chaque fois que vous apporterez des modifications à votre dépôt GitHub. Pour mettre à jour votre page :

1. Modifiez les fichiers dans votre dépôt
2. Committez et poussez les changements
3. GitHub Pages redéploiera automatiquement votre site

## Conclusion

Avec GitHub Pages, vous disposez maintenant d'une solution d'hébergement gratuite, fiable et sécurisée pour votre page intermédiaire. Le tout fonctionne avec votre nom de domaine personnalisé et est facilement maintenable via GitHub.

Cette configuration vous permet de bénéficier des avantages d'un hébergement professionnel sans aucun coût, tout en gardant un contrôle total sur votre contenu.