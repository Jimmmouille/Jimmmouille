# Guide d'hébergement gratuit sur Netlify avec un nom de domaine personnalisé

Ce guide détaillé vous explique comment héberger gratuitement votre page intermédiaire sur Netlify tout en utilisant votre nom de domaine existant (byjimjoum.com).

## Pourquoi Netlify ?

Netlify est une plateforme moderne d'hébergement et de déploiement continu qui offre un plan gratuit très généreux. Voici ses avantages principaux :

- **Totalement gratuit** pour les sites personnels et les projets avec un trafic modéré
- **HTTPS automatique et gratuit** avec certificat SSL Let's Encrypt
- **Déploiement continu** directement depuis GitHub, GitLab, ou Bitbucket
- **Interface utilisateur intuitive** sans besoin de connaissances techniques avancées
- **Support des noms de domaine personnalisés** sur le plan gratuit
- **Fonctionnalités avancées** comme les formulaires, les fonctions serverless et plus

## Prérequis

- Un compte GitHub, GitLab ou Bitbucket (pour stocker votre code)
- Accès aux paramètres DNS de votre domaine byjimjoum.com
- Votre page HTML intermédiaire (déjà créée)

## Étape 1 : Préparer votre site

1. Créez un dépôt sur GitHub, GitLab ou Bitbucket
2. Ajoutez votre fichier HTML sous le nom `index.html` à la racine du dépôt
3. Committez et poussez les changements

## Étape 2 : Créer un compte Netlify

1. Rendez-vous sur [netlify.com](https://www.netlify.com/) et cliquez sur "Sign up"
2. Choisissez de vous connecter avec votre compte GitHub, GitLab ou Bitbucket
3. Autorisez Netlify à accéder à vos dépôts

## Étape 3 : Déployer votre site sur Netlify

1. Une fois connecté à Netlify, cliquez sur "New site from Git"
2. Sélectionnez votre fournisseur de dépôt (GitHub, GitLab, ou Bitbucket)
3. Choisissez le dépôt contenant votre site
4. Dans les paramètres de déploiement :
   - **Build command** : laissez vide (car c'est un site statique simple)
   - **Publish directory** : laissez sur la valeur par défaut (`/`) ou spécifiez le dossier contenant votre `index.html`
5. Cliquez sur "Deploy site"

Netlify va maintenant déployer votre site et lui attribuer un sous-domaine aléatoire (exemple : `random-name-123456.netlify.app`).

## Étape 4 : Personnaliser le sous-domaine Netlify

Avant de configurer votre domaine personnalisé, vous pouvez optionnellement personnaliser le sous-domaine Netlify :

1. Dans le tableau de bord de votre site, allez dans "Site settings"
2. Sous "Site information", cliquez sur "Change site name"
3. Entrez un nom plus mémorable (exemple : `jimjoum-contact`)
4. Votre site sera maintenant accessible à `jimjoum-contact.netlify.app`

## Étape 5 : Ajouter votre domaine personnalisé

1. Dans le tableau de bord de votre site Netlify, allez dans l'onglet "Domain settings"
2. Cliquez sur "Add custom domain"
3. Entrez votre domaine : `byjimjoum.com`
4. Cliquez sur "Verify" puis "Add domain"

## Étape 6 : Configurer les paramètres DNS

Vous avez deux options pour configurer votre domaine avec Netlify :

### Option 1 : Utiliser les serveurs DNS de Netlify (recommandé)

Cette option est la plus simple et offre le meilleur contrôle :

1. Dans les paramètres de domaine de Netlify, à côté de votre domaine personnalisé, cliquez sur "Set up Netlify DNS"
2. Suivez les instructions pour ajouter les serveurs de noms (nameservers) de Netlify à votre registrar de domaine
3. Les serveurs de noms de Netlify sont généralement :
   - `dns1.p01.nsone.net`
   - `dns2.p01.nsone.net`
   - `dns3.p01.nsone.net`
   - `dns4.p01.nsone.net`
4. Une fois les serveurs de noms mis à jour chez votre registrar, cliquez sur "Verify" dans Netlify

### Option 2 : Conserver vos serveurs DNS actuels

Si vous préférez garder votre fournisseur DNS actuel :

1. Dans les paramètres de domaine de votre site Netlify, sous votre domaine personnalisé, vous verrez les enregistrements DNS à ajouter
2. Ajoutez ces enregistrements chez votre fournisseur DNS :

Pour le domaine apex (byjimjoum.com) :
| Type | Nom/Hôte | Valeur               | TTL     |
|------|----------|---------------------|---------|
| A    | @        | 75.2.60.5           | 1 heure |

Pour le sous-domaine www (www.byjimjoum.com) :
| Type  | Nom/Hôte | Valeur                    | TTL     |
|-------|----------|--------------------------|---------|
| CNAME | www      | jimjoum-contact.netlify.app | 1 heure |

## Étape 7 : Activer HTTPS

Netlify active automatiquement HTTPS pour tous les sites, y compris ceux avec des domaines personnalisés :

1. Une fois les DNS correctement configurés, Netlify provisionnera automatiquement un certificat SSL via Let's Encrypt
2. Dans les paramètres de domaine, sous "HTTPS", vous verrez le statut du certificat
3. L'émission du certificat peut prendre jusqu'à 24 heures, mais généralement c'est beaucoup plus rapide (environ 15 minutes)

## Étape 8 : Vérifier que tout fonctionne

1. Visitez votre domaine personnalisé (byjimjoum.com) dans un navigateur
2. Vérifiez que votre page intermédiaire s'affiche correctement
3. Vérifiez que la connexion est sécurisée (HTTPS) en cherchant le cadenas dans la barre d'adresse

## Dépannage

### Le site n'est pas accessible

- Vérifiez que les changements DNS ont eu le temps de se propager (cela peut prendre jusqu'à 24 heures)
- Vérifiez que les enregistrements DNS sont correctement configurés
- Utilisez un outil comme [dnschecker.org](https://dnschecker.org/) pour vérifier la propagation DNS

### Erreur de certificat SSL

- Assurez-vous que les DNS sont correctement configurés
- Vérifiez le statut du certificat dans les paramètres HTTPS de Netlify
- Si nécessaire, vous pouvez demander manuellement la reémission du certificat

### Problèmes avec les redirections www/apex

Netlify gère automatiquement les redirections entre le domaine apex et www. Si vous rencontrez des problèmes :

1. Dans les paramètres de domaine, sous "Custom domains"
2. Vérifiez que les deux domaines (apex et www) sont correctement configurés
3. Assurez-vous que la redirection primaire est configurée selon vos préférences

## Fonctionnalités supplémentaires de Netlify

Netlify offre de nombreuses fonctionnalités avancées même sur le plan gratuit :

- **Formulaires** : Collectez des données sans avoir besoin d'un backend (limité à 100 soumissions/mois sur le plan gratuit)
- **Fonctions serverless** : Ajoutez des fonctionnalités backend sans serveur (limité à 125k invocations/mois)
- **Déploiement par branche** : Testez les changements dans des environnements isolés
- **Aperçus de déploiement** : Prévisualisez vos modifications avant de les mettre en production
- **Analytics de base** : Suivez les visiteurs et les performances de votre site

## Maintenance

Pour mettre à jour votre site, il vous suffit de pousser les changements vers votre dépôt Git :

1. Modifiez les fichiers localement
2. Committez et poussez les changements
3. Netlify détectera automatiquement les modifications et redéploiera votre site

## Conclusion

Netlify offre une solution d'hébergement gratuite, robuste et facile à utiliser pour votre page intermédiaire. Le plan gratuit est largement suffisant pour un site personnel, et la configuration avec un domaine personnalisé est simple et rapide.

Cette solution vous permet de bénéficier d'une infrastructure moderne et sécurisée sans frais, tout en gardant une flexibilité maximale pour l'avenir.