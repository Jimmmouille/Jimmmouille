# Programming the Vivokey Spark 2 NFC Implant

This guide will walk you through the process of programming your Vivokey Spark 2 implant to redirect to your data collection page.

## Prerequisites

1. A smartphone with NFC capabilities:
   - Android: Most modern Android phones have NFC
   - iOS: iPhone 7 or newer with iOS 13 or above

2. NFC programming app:
   - **NFC Tools** (Recommended for simplicity): [Android](https://play.google.com/store/apps/details?id=com.wakdev.wdnfc) | [iOS](https://apps.apple.com/app/nfc-tools/id1252962749)
   - Alternative: **NXP TagWriter**: [Android](https://play.google.com/store/apps/details?id=com.nxp.nfc.tagwriter) | [iOS](https://apps.apple.com/app/nxp-tagwriter/id1246143596)

3. Your data collection page URL ready

## Step-by-Step Programming Instructions

### Using NFC Tools App

1. **Install the NFC Tools app** on your smartphone

2. **Open the NFC Tools app**

3. **Ensure NFC is enabled** on your device:
   - On Android: Go to Settings > Connected devices > Connection preferences > NFC
   - On iOS: NFC reading is always enabled on compatible devices (iPhone 7 and newer)

4. **Prepare for writing**:
   - In the NFC Tools app, navigate to the WRITE tab
   - Tap "Add a record"
   - Select "URL/URI"
   - Enter the full URL of your data collection page (e.g., https://your-domain.com/nfc-collection)
   - Make sure to include the "https://" prefix for proper functionality
   - Tap "OK" to confirm

5. **Write to the implant**:
   - The app will prompt you to place your phone near the NFC tag
   - Hold your phone near your Vivokey Spark 2 implant (typically implanted between thumb and index finger)
   - Keep the phone still until the app confirms successful writing
   - You might need to try different positions to find the optimal scanning spot

6. **Verify successful programming**:
   - Switch to the READ tab in the app
   - Scan your implant again to verify the URL was written correctly
   - You can also test with your phone's native NFC scanning functionality:
     - On Android: Simply hold your phone near the implant
     - On iOS: Either use the background NFC scanning feature or Control Center NFC scanner

### Using NXP TagWriter App

1. **Install the NXP TagWriter app** on your smartphone

2. **Open the NXP TagWriter app**

3. **Write data to the implant**:
   - Tap on "Write tags"
   - Select "Links"
   - Choose "URL" from the options
   - Enter your data collection page URL (include the "https://" prefix)
   - For iOS compatibility, leave the description field blank
   - Tap "Write" or similar button
   - Hold your phone near your implant until the app confirms successful writing

4. **Verify the programming**:
   - Use the "Scan tag" feature in the app
   - Hold your phone near the implant again
   - Confirm that the URL was written correctly

## Troubleshooting

### Common Issues and Solutions

1. **Write operation fails**:
   - Try repositioning your phone against the implant
   - Ensure there are no metallic objects between your phone and the implant
   - Check if your phone case is interfering with NFC functionality
   - Try using a different NFC app

2. **Permission issues**:
   - Make sure the NFC app has all necessary permissions
   - On Android, verify that NFC is enabled in your settings

3. **URL not opening automatically**:
   - Make sure you included the "https://" prefix in your URL
   - Try writing the URL again
   - Test with a different browser

4. **iOS-specific issues**:
   - iOS has stricter NFC handling than Android
   - Ensure you're using a fully qualified URL with https://
   - Try writing the URL using different apps if one doesn't work

### When to Seek Professional Help

If you encounter persistent issues programming your Vivokey Spark 2 implant, consider:

1. Contacting Vivokey support for technical assistance
2. Consulting with the professional who implanted the device
3. Reaching out to NFC programming specialists or communities online

## Best Practices

1. **Test before implantation** if possible (with a test tag of same type)
2. **Keep URLs short** to ensure compatibility
3. **Always use HTTPS** for security and proper functioning
4. **Document your implementation** for future reference
5. **Create a backup plan** in case you need to change the URL in the future

## Additional Resources

- [Vivokey Support](https://vivokey.com)
- [NFC Tools Documentation](https://www.wakdev.com/en/apps/nfc-tools.html)
- [NXP TagWriter Documentation](https://www.nxp.com/products/rfid-nfc)

Remember that the Vivokey Spark 2 is designed to be reprogrammable, so you can always update the URL if needed in the future.