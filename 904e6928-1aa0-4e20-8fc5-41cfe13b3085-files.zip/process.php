<?php
// Database configuration
$db_host = 'localhost';
$db_name = 'nfc_data';
$db_user = 'your_username';
$db_pass = 'your_password';

// URL of your personal website (where to redirect after form submission)
$personal_website_url = 'https://votre-site-personnel.com';

// Set headers for JSON response
header('Content-Type: application/json');

// Initialize response array
$response = [
    'success' => false,
    'message' => '',
    'redirect_url' => $personal_website_url
];

try {
    // Validate form data
    if (!isset($_POST['name']) || empty($_POST['name'])) {
        throw new Exception('Le nom est requis');
    }
    
    if (!isset($_POST['email']) || empty($_POST['email'])) {
        throw new Exception('L\'email est requis');
    }
    
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Format d\'email invalide');
    }
    
    // Sanitize input data
    $name = htmlspecialchars($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $message = isset($_POST['message']) ? htmlspecialchars($_POST['message']) : '';
    
    // Get location data
    $latitude = isset($_POST['latitude']) ? filter_var($_POST['latitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) : null;
    $longitude = isset($_POST['longitude']) ? filter_var($_POST['longitude'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) : null;
    $location_accuracy = isset($_POST['location_accuracy']) ? filter_var($_POST['location_accuracy'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION) : null;
    
    // Format scan date (use provided or current time)
    $scan_date = isset($_POST['scan_date']) ? $_POST['scan_date'] : date('Y-m-d H:i:s');
    
    // Get additional information
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    
    // Connect to database
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Prepare SQL statement
    $sql = "INSERT INTO scan_entries (
                visitor_name, 
                visitor_email, 
                visitor_message, 
                scan_date, 
                location_latitude, 
                location_longitude, 
                location_accuracy, 
                ip_address, 
                user_agent
            ) VALUES (
                :name, 
                :email, 
                :message, 
                :scan_date, 
                :latitude, 
                :longitude, 
                :accuracy, 
                :ip, 
                :user_agent
            )";
    
    $stmt = $pdo->prepare($sql);
    
    // Bind parameters
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':message', $message);
    $stmt->bindParam(':scan_date', $scan_date);
    $stmt->bindParam(':latitude', $latitude);
    $stmt->bindParam(':longitude', $longitude);
    $stmt->bindParam(':accuracy', $location_accuracy);
    $stmt->bindParam(':ip', $ip_address);
    $stmt->bindParam(':user_agent', $user_agent);
    
    // Execute the query
    $stmt->execute();
    
    // Check if the insertion was successful
    if ($stmt->rowCount() > 0) {
        $response['success'] = true;
        $response['message'] = 'Données enregistrées avec succès';
    } else {
        throw new Exception('Échec de l\'enregistrement des données');
    }
    
} catch (PDOException $e) {
    // Database error
    $response['message'] = 'Erreur de base de données: ' . $e->getMessage();
    
    // Log the error (don't show detailed DB errors to users in production)
    error_log('Database Error: ' . $e->getMessage());
    
} catch (Exception $e) {
    // General error
    $response['message'] = $e->getMessage();
}

// Send JSON response
echo json_encode($response);
exit;
?>