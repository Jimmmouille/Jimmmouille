# Résumé des recherches techniques pour la configuration de la puce Vivokey Spark 2

## Contexte
L'objectif est de configurer une puce NFC Vivokey Spark 2 implantée pour permettre aux personnes qui la scannent avec leur téléphone de partager automatiquement leurs informations de contact, leur localisation, la date et l'heure du scan, puis d'être redirigées vers un site web personnel.

## Points clés des recherches

### 1. Extraction automatique des contacts

L'extraction automatique des contacts est fortement limitée par les restrictions de sécurité et de confidentialité sur les appareils mobiles:

- **Contact Picker API**: Disponible principalement sur Chrome Android (v80+), nécessite une interaction utilisateur explicite et une autorisation à chaque utilisation.
- **Safari iOS**: Support très limité, nécessite l'activation d'un flag expérimental.
- **Accès automatique**: Impossible d'accéder aux contacts d'un utilisateur sans son consentement explicite et son action.

➡️ **Conclusion**: Il n'est pas possible d'extraire automatiquement les contacts du téléphone d'une personne qui scanne la puce NFC. L'utilisateur devra toujours interagir avec l'interface web pour partager ses informations.

### 2. Envoi de SMS depuis le navigateur

L'envoi automatique de SMS depuis un navigateur web est également très restreint:

- **Schéma d'URI `sms:`**: Permet d'ouvrir l'application de messagerie avec un numéro et un message pré-rempli, mais:
  - Le support du corps du message est inégal entre iOS et Android
  - L'utilisateur doit toujours appuyer sur "Envoyer" manuellement
  - Impossible d'envoyer un SMS en arrière-plan sans interaction
- **APIs SMS directes**: N'existent pas pour les sites web standard pour des raisons de sécurité et de coûts.

➡️ **Conclusion**: La meilleure approche est d'utiliser un lien `sms:` qui pré-remplit un message avec les informations collectées, mais l'utilisateur devra toujours appuyer manuellement sur "Envoyer".

### 3. Géolocalisation automatique

La géolocalisation via navigateur est possible mais soumise à des contraintes:

- **Geolocation API**: Largement supportée, mais:
  - Nécessite une autorisation explicite de l'utilisateur
  - Fonctionne uniquement en HTTPS
  - Ne peut pas être déclenchée sans interaction utilisateur préalable
- **Précision**: Très bonne avec le GPS (10-20m), moins bonne avec les autres méthodes

➡️ **Conclusion**: Il est possible d'obtenir la localisation de l'utilisateur avec son consentement, mais pas de manière entièrement automatique.

## Solution technique recommandée

Compte tenu des limitations identifiées, voici la solution la plus adaptée:

1. **Configurer la puce NFC** pour ouvrir une URL pointant vers une page web hébergée gratuitement

2. **Sur la page web intermédiaire**:
   - Afficher un formulaire simple demandant les informations minimales (nom, prénom)
   - Proposer un bouton "Partager ma position et mes coordonnées"
   - Lorsque l'utilisateur clique sur ce bouton:
     - Demander l'autorisation de géolocalisation
     - Récupérer la date et l'heure actuelles
     - Préparer un message SMS contenant ces informations
     - Ouvrir l'application SMS avec le message pré-rempli
   - Après l'envoi du SMS (ou l'annulation), rediriger vers le site web personnel

3. **Implémentation technique**:
   ```html
   <!DOCTYPE html>
   <html>
   <head>
       <title>Contact Rapide</title>
       <meta name="viewport" content="width=device-width, initial-scale=1">
       <meta charset="UTF-8">
   </head>
   <body>
       <h1>Bonjour!</h1>
       <p>Merci de scanner ma puce NFC!</p>
       
       <form id="contactForm">
           <input type="text" id="name" placeholder="Votre nom" required>
           <input type="text" id="firstName" placeholder="Votre prénom" required>
           <button type="button" onclick="getLocationAndPrepareSMS()">Partager mes coordonnées</button>
       </form>
       
       <script>
       function getLocationAndPrepareSMS() {
           const name = document.getElementById('name').value;
           const firstName = document.getElementById('firstName').value;
           
           if (!name || !firstName) {
               alert("Veuillez saisir votre nom et prénom");
               return;
           }
           
           const currentTime = new Date().toLocaleString();
           
           if (navigator.geolocation) {
               navigator.geolocation.getCurrentPosition(
                   // Succès
                   function(position) {
                       const lat = position.coords.latitude;
                       const lng = position.coords.longitude;
                       const locationText = `${lat}, ${lng}`;
                       
                       // Créer le lien SMS
                       const smsBody = `Bonjour, je m'appelle ${firstName} ${name}. J'ai scanné votre puce NFC à la position: ${locationText} le ${currentTime}`;
                       const smsLink = `sms:+33600000000?body=${encodeURIComponent(smsBody)}`;
                       
                       // Ouvrir l'app SMS
                       window.location.href = smsLink;
                       
                       // Rediriger vers le site personnel après 5 secondes
                       setTimeout(function() {
                           window.location.href = "https://votre-site-personnel.com";
                       }, 5000);
                   },
                   // Erreur
                   function(error) {
                       // En cas d'erreur, utiliser juste le nom et la date
                       const smsBody = `Bonjour, je m'appelle ${firstName} ${name}. J'ai scanné votre puce NFC le ${currentTime}`;
                       const smsLink = `sms:+33600000000?body=${encodeURIComponent(smsBody)}`;
                       
                       window.location.href = smsLink;
                       
                       // Rediriger vers le site personnel après 5 secondes
                       setTimeout(function() {
                           window.location.href = "https://votre-site-personnel.com";
                       }, 5000);
                   }
               );
           } else {
               // Si la géolocalisation n'est pas supportée
               const smsBody = `Bonjour, je m'appelle ${firstName} ${name}. J'ai scanné votre puce NFC le ${currentTime}`;
               const smsLink = `sms:+33600000000?body=${encodeURIComponent(smsBody)}`;
               
               window.location.href = smsLink;
               
               // Rediriger vers le site personnel après 5 secondes
               setTimeout(function() {
                   window.location.href = "https://votre-site-personnel.com";
               }, 5000);
           }
       }
       </script>
   </body>
   </html>
   ```

Cette solution représente le meilleur compromis entre les fonctionnalités souhaitées et les restrictions techniques imposées par les navigateurs et systèmes d'exploitation mobiles. Elle est entièrement gratuite et ne nécessite pas d'infrastructure serveur complexe.