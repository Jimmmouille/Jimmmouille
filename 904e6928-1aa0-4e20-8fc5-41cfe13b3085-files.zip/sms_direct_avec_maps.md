# Solution finale pour l'envoi de SMS avec lien Google Maps

## Fonctionnalités intégrées

La solution complète inclut désormais :
1. La collecte des informations de contact (nom, prénom, date de naissance, email)
2. La géolocalisation automatique avec permission
3. Un lien Google Maps pour visualiser l'emplacement exact du scan
4. L'envoi d'un SMS prérempli à votre numéro (+33 07 66 01 87 52)
5. La redirection vers votre site web personnel après l'envoi du SMS

## Code HTML/JavaScript optimisé

```html
<!DOCTYPE html>
<html>
<head>
    <title>Contact Rapide</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            text-align: center;
            max-width: 600px;
            margin: 0 auto;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px 0;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #4285F4;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 20px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
        }
        button:hover {
            background-color: #3367D6;
        }
        #status {
            margin-top: 20px;
            font-style: italic;
            color: #666;
        }
        .privacy-note {
            font-size: 12px;
            color: #666;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Bonjour!</h1>
    <p>Merci de scanner ma puce NFC. Partagez vos coordonnées pour que je puisse vous recontacter.</p>
    
    <form id="contactForm">
        <div class="form-group">
            <label for="name">Nom</label>
            <input type="text" id="name" placeholder="Votre nom" required>
        </div>
        
        <div class="form-group">
            <label for="firstName">Prénom</label>
            <input type="text" id="firstName" placeholder="Votre prénom" required>
        </div>
        
        <div class="form-group">
            <label for="birthdate">Date de naissance</label>
            <input type="date" id="birthdate">
        </div>
        
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" placeholder="Votre email">
        </div>
        
        <button type="button" onclick="getLocationAndPrepareSMS()">Partager mes coordonnées</button>
    </form>
    
    <div id="status"></div>
    
    <p class="privacy-note">
        En cliquant sur "Partager mes coordonnées", votre position actuelle sera obtenue (avec votre permission) 
        et un SMS sera préparé avec vos informations. Vous pourrez vérifier le contenu du message avant de l'envoyer.
    </p>
    
    <script>
    // Variable pour stocker l'URL de votre site web personnel
    const personalWebsiteURL = "https://votre-site-personnel.com";
    
    function getLocationAndPrepareSMS() {
        const name = document.getElementById('name').value;
        const firstName = document.getElementById('firstName').value;
        const birthdate = document.getElementById('birthdate').value;
        const email = document.getElementById('email').value;
        
        if (!name || !firstName) {
            alert("Veuillez saisir au moins votre nom et prénom");
            return;
        }
        
        const currentTime = new Date().toLocaleString();
        const statusDiv = document.getElementById('status');
        statusDiv.innerHTML = "Obtention de votre localisation...";
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                // Succès
                function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    
                    // Créer le lien Google Maps
                    const googleMapsLink = `https://maps.google.com/?q=${lat},${lng}`;
                    
                    // Construire le message avec toutes les informations
                    let smsBody = `Contact NFC: ${firstName} ${name}`;
                    
                    if (birthdate) {
                        smsBody += `, né(e) le ${birthdate}`;
                    }
                    
                    if (email) {
                        smsBody += `, email: ${email}`;
                    }
                    
                    smsBody += `. Scan effectué le ${currentTime}. Localisation: ${googleMapsLink}`;
                    
                    // Créer le lien SMS avec numéro direct
                    const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
                    
                    statusDiv.innerHTML = "Ouverture de l'application SMS...";
                    
                    // Ouvrir l'application SMS
                    window.location.href = smsLink;
                    
                    // Rediriger vers le site personnel après 3 secondes
                    setTimeout(function() {
                        statusDiv.innerHTML = "Redirection vers le site principal...";
                        window.location.href = personalWebsiteURL;
                    }, 3000);
                },
                // Erreur
                function(error) {
                    console.log("Erreur de géolocalisation:", error);
                    statusDiv.innerHTML = "Impossible d'obtenir la localisation. Préparation du SMS sans localisation...";
                    
                    // En cas d'erreur de géolocalisation
                    let smsBody = `Contact NFC: ${firstName} ${name}`;
                    
                    if (birthdate) {
                        smsBody += `, né(e) le ${birthdate}`;
                    }
                    
                    if (email) {
                        smsBody += `, email: ${email}`;
                    }
                    
                    smsBody += `. Scan effectué le ${currentTime}. (Localisation non disponible)`;
                    
                    const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
                    
                    // Ouvrir l'application SMS
                    window.location.href = smsLink;
                    
                    // Rediriger vers le site personnel après 3 secondes
                    setTimeout(function() {
                        window.location.href = personalWebsiteURL;
                    }, 3000);
                },
                // Options de géolocalisation
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        } else {
            // Si la géolocalisation n'est pas supportée
            statusDiv.innerHTML = "Géolocalisation non supportée par votre navigateur. Préparation du SMS sans localisation...";
            
            let smsBody = `Contact NFC: ${firstName} ${name}`;
            
            if (birthdate) {
                smsBody += `, né(e) le ${birthdate}`;
            }
            
            if (email) {
                smsBody += `, email: ${email}`;
            }
            
            smsBody += `. Scan effectué le ${currentTime}. (Localisation non disponible)`;
            
            const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
            
            // Ouvrir l'application SMS
            window.location.href = smsLink;
            
            // Rediriger vers le site personnel après 3 secondes
            setTimeout(function() {
                window.location.href = personalWebsiteURL;
            }, 3000);
        }
    }
    </script>
</body>
</html>
```

## Points clés améliorés

### 1. Intégration de Google Maps
Au lieu d'inclure seulement les coordonnées brutes, j'ai ajouté un lien direct vers Google Maps :

```javascript
const googleMapsLink = `https://maps.google.com/?q=${lat},${lng}`;
```

Ce lien, lorsqu'il est cliqué dans le SMS, ouvrira directement Google Maps à l'emplacement exact où le scan a été effectué, offrant une visualisation intuitive et facile de la localisation.

### 2. Redirection automatique vers votre site web
Le code contient maintenant une variable `personalWebsiteURL` que vous pourrez facilement modifier pour spécifier l'adresse de votre site web personnel :

```javascript
const personalWebsiteURL = "https://votre-site-personnel.com";
```

Après l'ouverture de l'application SMS, un délai de 3 secondes est observé avant la redirection vers votre site web, donnant à l'utilisateur le temps d'envoyer le SMS :

```javascript
setTimeout(function() {
    window.location.href = personalWebsiteURL;
}, 3000);
```

### 3. Gestion améliorée des erreurs
Le code a été revu pour assurer une meilleure gestion des erreurs :
- Messages d'erreur plus informatifs
- Abandon gracieux quand la géolocalisation échoue
- Informations claires sur l'absence de localisation dans le message

### 4. Format du SMS optimisé
Le format du message SMS a été revu pour être concis tout en contenant toutes les informations importantes :
```
Contact NFC: [Prénom] [Nom], né(e) le [Date naissance], email: [Email]. Scan effectué le [Date/Heure]. Localisation: [Lien Google Maps]
```

## Instructions pour le déploiement

1. Téléchargez ce fichier HTML sur votre serveur web ou service d'hébergement gratuit
2. Remplacez `"https://votre-site-personnel.com"` par l'URL réelle de votre site web personnel
3. Si vous le souhaitez, personnalisez le design CSS pour correspondre à votre identité visuelle
4. Programmez votre puce Vivokey Spark 2 pour pointer vers l'URL de cette page HTML
5. Testez le fonctionnement sur différents appareils (Android et iOS)

Cette solution offre maintenant tout ce que vous avez demandé :
- Collecte des informations de contact
- Géolocalisation via Google Maps
- Envoi de SMS à votre numéro spécifique
- Redirection vers votre site web personnel
- Le tout de manière entièrement gratuite et sans nécessiter d'infrastructure serveur complexe