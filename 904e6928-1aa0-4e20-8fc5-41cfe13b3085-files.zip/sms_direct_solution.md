# Solution pour l'envoi direct de SMS à un numéro prédéfini

Pour envoyer un SMS directement à votre numéro de téléphone spécifique (+33 07 66 01 87 52), nous allons utiliser le schéma d'URI `sms:` avec votre numéro prédéfini comme destinataire.

## Approche optimisée

### 1. Structure du lien SMS

```
sms:+33766018752?body=Message_à_envoyer
```

Remarques importantes:
- J'ai retiré l'espace et le "0" après le code pays car cela pourrait causer des problèmes dans certains systèmes
- Le corps du message sera toujours URL-encodé pour éviter les problèmes de caractères spéciaux

### 2. Mise en œuvre dans le HTML/JavaScript

```html
<!DOCTYPE html>
<html>
<head>
    <title>Contact Rapide</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            text-align: center;
            max-width: 600px;
            margin: 0 auto;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
        }
        form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin: 20px 0;
        }
        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        button {
            background-color: #4285F4;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 12px 20px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
        }
        button:hover {
            background-color: #3367D6;
        }
        #status {
            margin-top: 20px;
            font-style: italic;
            color: #666;
        }
        .privacy-note {
            font-size: 12px;
            color: #666;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Bonjour!</h1>
    <p>Merci de scanner ma puce NFC. Partagez vos coordonnées pour que je puisse vous recontacter.</p>
    
    <form id="contactForm">
        <div class="form-group">
            <label for="name">Nom</label>
            <input type="text" id="name" placeholder="Votre nom" required>
        </div>
        
        <div class="form-group">
            <label for="firstName">Prénom</label>
            <input type="text" id="firstName" placeholder="Votre prénom" required>
        </div>
        
        <div class="form-group">
            <label for="birthdate">Date de naissance</label>
            <input type="date" id="birthdate">
        </div>
        
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" placeholder="Votre email">
        </div>
        
        <button type="button" onclick="getLocationAndPrepareSMS()">Partager mes coordonnées</button>
    </form>
    
    <div id="status"></div>
    
    <p class="privacy-note">
        En cliquant sur "Partager mes coordonnées", votre position actuelle sera obtenue (avec votre permission) 
        et un SMS sera préparé avec vos informations. Vous pourrez vérifier le contenu du message avant de l'envoyer.
    </p>
    
    <script>
    function getLocationAndPrepareSMS() {
        const name = document.getElementById('name').value;
        const firstName = document.getElementById('firstName').value;
        const birthdate = document.getElementById('birthdate').value;
        const email = document.getElementById('email').value;
        
        if (!name || !firstName) {
            alert("Veuillez saisir au moins votre nom et prénom");
            return;
        }
        
        const currentTime = new Date().toLocaleString();
        const statusDiv = document.getElementById('status');
        statusDiv.innerHTML = "Préparation du message...";
        
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                // Succès
                function(position) {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    const locationText = `${lat}, ${lng}`;
                    
                    // Construire le message avec toutes les informations
                    let smsBody = `Contact NFC: ${firstName} ${name}`;
                    
                    if (birthdate) {
                        smsBody += `, né(e) le ${birthdate}`;
                    }
                    
                    if (email) {
                        smsBody += `, email: ${email}`;
                    }
                    
                    smsBody += `. Position: ${locationText}. Scanné le ${currentTime}`;
                    
                    // Créer le lien SMS avec numéro direct
                    const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
                    
                    statusDiv.innerHTML = "Ouverture de l'application SMS...";
                    
                    // Ouvrir l'application SMS
                    window.location.href = smsLink;
                    
                    // Rediriger vers le site personnel après 5 secondes
                    setTimeout(function() {
                        statusDiv.innerHTML = "Redirection vers le site principal...";
                        window.location.href = "https://votre-site-personnel.com";
                    }, 5000);
                },
                // Erreur
                function(error) {
                    // En cas d'erreur de géolocalisation
                    let smsBody = `Contact NFC: ${firstName} ${name}`;
                    
                    if (birthdate) {
                        smsBody += `, né(e) le ${birthdate}`;
                    }
                    
                    if (email) {
                        smsBody += `, email: ${email}`;
                    }
                    
                    smsBody += `. Scanné le ${currentTime}`;
                    
                    const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
                    
                    statusDiv.innerHTML = "Ouverture de l'application SMS...";
                    window.location.href = smsLink;
                    
                    // Rediriger vers le site personnel après 5 secondes
                    setTimeout(function() {
                        statusDiv.innerHTML = "Redirection vers le site principal...";
                        window.location.href = "https://votre-site-personnel.com";
                    }, 5000);
                },
                // Options de géolocalisation
                {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                }
            );
        } else {
            // Si la géolocalisation n'est pas supportée
            let smsBody = `Contact NFC: ${firstName} ${name}`;
            
            if (birthdate) {
                smsBody += `, né(e) le ${birthdate}`;
            }
            
            if (email) {
                smsBody += `, email: ${email}`;
            }
            
            smsBody += `. Scanné le ${currentTime}`;
            
            const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
            
            statusDiv.innerHTML = "Ouverture de l'application SMS...";
            window.location.href = smsLink;
            
            // Rediriger vers le site personnel après 5 secondes
            setTimeout(function() {
                statusDiv.innerHTML = "Redirection vers le site principal...";
                window.location.href = "https://votre-site-personnel.com";
            }, 5000);
        }
    }
    </script>
</body>
</html>
```

### 3. Considérations de compatibilité

Pour garantir un fonctionnement optimal sur tous les appareils, voici quelques variantes du lien SMS que nous pourrions essayer si la première méthode échoue:

#### Pour iOS:
```javascript
// Option 1: Format standard avec numéro international
const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;

// Option 2: Format avec double slash (recommandé pour certaines versions d'iOS)
const smsLink = `sms://+33766018752?body=${encodeURIComponent(smsBody)}`;

// Option 3: Format sans + pour le code international
const smsLink = `sms:33766018752?body=${encodeURIComponent(smsBody)}`;
```

#### Pour Android:
```javascript
// Le format standard fonctionne généralement bien
const smsLink = `sms:+33766018752?body=${encodeURIComponent(smsBody)}`;
```

### 4. Optimisations

Pour assurer une expérience utilisateur optimale:

1. **Feedback visuel**: L'utilisateur voit clairement son statut grâce au div "status"
2. **Design responsive**: La page s'adapte à tous les types d'écrans
3. **Gestion d'erreurs**: Traitement des cas où la géolocalisation est refusée ou non disponible
4. **Redirection progressive**: L'utilisateur a le temps d'envoyer son SMS avant d'être redirigé
5. **Note de confidentialité**: Pour rassurer l'utilisateur sur l'utilisation de ses données

## Limitations persistantes

Malgré cette approche optimisée, certaines limitations demeurent:

1. **Envoi manuel**: L'utilisateur devra toujours appuyer manuellement sur "Envoyer" dans son application SMS
2. **Vérification préalable**: L'utilisateur pourra voir et potentiellement modifier le message avant envoi
3. **Dépendance à l'application SMS**: L'appareil doit avoir une application SMS fonctionnelle
4. **Permission de géolocalisation**: La localisation précise nécessite l'accord de l'utilisateur
5. **Temps de redirection**: Le délai de 5 secondes peut être trop court ou trop long selon les cas

Ces limitations sont inhérentes aux contraintes de sécurité des navigateurs mobiles et ne peuvent être contournées sans utiliser des APIs ou services payants.