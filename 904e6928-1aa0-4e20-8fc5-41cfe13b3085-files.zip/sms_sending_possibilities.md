# Possibilités d'envoi de SMS depuis un navigateur web

## Schéma d'URI SMS

Le schéma d'URI `sms:` est le moyen principal pour initier l'envoi d'un SMS depuis un navigateur web. Il permet d'ouvrir l'application de messagerie native de l'appareil avec un numéro de destinataire et, sur certains appareils, un corps de message pré-rempli.

### Syntaxe de base
```
sms:+numérodetéléphone?body=texte du message
```

### Support par plateforme

#### iOS (iPhone)
- Supporte l'ouverture de l'application Messages avec un numéro pré-rempli
- Le corps du message (`body`) n'est **pas** supporté sur les anciennes versions d'iOS
- Sur les versions récentes d'iOS, le corps du message est partiellement supporté

#### Android
- Supporte l'ouverture de l'application de messagerie avec un numéro pré-rempli
- Supporte le corps du message (`body`) sur la plupart des appareils et navigateurs

### Exemple d'implémentation
```html
<a href="sms:+33600000000?body=Bonjour, voici mes coordonnées: [NOM] [PRÉNOM]. J'ai scanné votre puce NFC à [LOCATION] le [DATE] à [HEURE].">Partager mes coordonnées par SMS</a>
```

### Limitations
1. **Pas d'envoi automatique** : L'utilisateur doit manuellement appuyer sur "Envoyer" dans son application de messagerie
2. **Support inégal** : Le pré-remplissage du corps du message n'est pas supporté de manière uniforme
3. **Pas d'accès programmatique** : Impossible d'accéder aux contacts ou d'envoyer un SMS directement via JavaScript
4. **Limites de longueur** : Les URL ont des limites de longueur qui peuvent poser problème pour de longs messages

## Alternatives à l'envoi direct de SMS

### Services d'API SMS (nécessitent un coût)
Des services comme Twilio, MessageBird ou Vonage (anciennement Nexmo) permettent d'envoyer des SMS depuis un serveur, mais ils :
- Ne sont pas gratuits
- Nécessitent une configuration côté serveur
- Ne permettent pas l'envoi depuis le téléphone de l'utilisateur

### Progressive Web Apps (PWA)
Les PWA peuvent, dans certains cas, accéder à des API natives plus avancées, mais même dans ce cas, l'envoi direct de SMS reste limité pour des raisons de sécurité.

### WebSMS (non standard)
Certains opérateurs proposent des services de "WebSMS" permettant d'envoyer des SMS depuis un navigateur, mais ces solutions sont :
- Spécifiques à un opérateur
- Souvent payantes
- Non standardisées

## Solution la plus appropriée

Pour le cas d'usage d'une puce NFC renvoyant vers un site web qui doit permettre l'envoi d'un SMS avec les coordonnées de l'utilisateur, la meilleure approche serait :

1. **Utiliser une interface simple qui collecte les informations minimales nécessaires** (nom, prénom)
2. **Récupérer automatiquement la date, l'heure et si possible la localisation** (via l'API Geolocation)
3. **Générer un lien `sms:` avec toutes ces informations pré-remplies** dans le corps du message
4. **Afficher clairement que l'utilisateur doit appuyer sur "Envoyer"** dans son application de messagerie

Cette approche a l'avantage d'être universelle, de ne pas nécessiter de serveur ou de service payant, et de respecter les contraintes de sécurité des navigateurs modernes.