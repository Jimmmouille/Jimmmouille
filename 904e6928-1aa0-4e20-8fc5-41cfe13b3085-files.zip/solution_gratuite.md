# Solution Gratuite pour Configurer la Puce Vivokey Spark 2

Puisque vous souhaitez mettre en place cette solution entièrement gratuitement, voici comment adapter le projet en utilisant exclusivement des services gratuits.

## Hébergement Web et Base de Données Gratuits

### Option 1: InfinityFree

[InfinityFree](https://www.infinityfree.com/) est l'une des meilleures solutions d'hébergement gratuit pour ce projet:

**Avantages:**
- PHP 8.2 et MySQL 8.0/MariaDB 10.6
- 5 Go d'espace disque
- Bande passante illimitée
- 400 bases de données MySQL
- Possibilité d'utiliser votre propre nom de domaine
- PAS de publicités sur votre site
- Certificat SSL gratuit
- Uptime de 99,9%

**Étapes d'installation:**
1. Créez un compte sur InfinityFree
2. Configurez votre domaine existant ou utilisez un sous-domaine gratuit
3. Créez une base de données MySQL
4. Téléchargez les fichiers du projet via le gestionnaire de fichiers ou FTP

### Option 2: AwardSpace

[AwardSpace](https://www.awardspace.com/free-hosting/) est une autre option viable:

**Avantages:**
- 100% sans publicité
- Compatible PHP et MySQL
- Support client 24/7
- Uptime de 99,9%
- Gestionnaire de fichiers intégré

### Option 3: Freehostia

[Freehostia](https://www.freehostia.com/) offre un plan gratuit "Chocolate":
- 250 Mo d'espace disque
- 6 Go de trafic mensuel
- 1 base de données MySQL (10 Mo)
- 3 comptes email

## Alternatives Sans Base de Données

Si la configuration d'une base de données MySQL vous semble complexe, vous pouvez utiliser des solutions plus simples:

### Option 1: Stockage JSON avec GitHub Pages

1. Hébergez votre page de collecte sur GitHub Pages (gratuit)
2. Utilisez un webhook gratuit comme [Pipedream](https://pipedream.com/) (offre un niveau gratuit généreux)
3. Lorsque le formulaire est soumis, les données sont envoyées à Pipedream
4. Pipedream peut stocker les données ou les envoyer par email

### Option 2: Netlify Forms + GitHub Pages

1. Hébergez votre site sur GitHub Pages ou Netlify (gratuit)
2. Utilisez [Netlify Forms](https://www.netlify.com/products/forms/) (permet 100 soumissions gratuites par mois)
3. Les données sont stockées dans votre tableau de bord Netlify
4. Vous pouvez configurer des notifications par email

### Option 3: Google Sheets comme Base de Données

1. Créez un formulaire Google qui collecte les informations
2. Les réponses sont automatiquement enregistrées dans Google Sheets
3. Utilisez [SheetDB](https://sheetdb.io/) (offre un niveau gratuit) pour connecter votre formulaire HTML à Google Sheets

## Adaptation du Code pour Solutions Gratuites

### Utilisation de Google Sheets (Exemple)

Voici comment adapter le code pour utiliser Google Sheets au lieu d'une base de données traditionnelle:

1. Créez un formulaire Google et notez son URL
2. Modifiez le fichier HTML pour envoyer les données au formulaire Google:

```html
<form id="contact-form" action="https://docs.google.com/forms/d/e/YOUR_FORM_ID/formResponse" method="post" target="hidden_iframe">
    <input type="text" name="entry.XXXXXX" id="name" required placeholder="Votre Nom">
    <input type="email" name="entry.XXXXXX" id="email" required placeholder="Votre Email">
    <textarea name="entry.XXXXXX" id="message" placeholder="Message (optionnel)"></textarea>
    
    <!-- Champs cachés pour la géolocalisation -->
    <input type="hidden" name="entry.XXXXXX" id="latitude">
    <input type="hidden" name="entry.XXXXXX" id="longitude">
    
    <button type="submit">Envoyer et continuer</button>
</form>
<iframe name="hidden_iframe" id="hidden_iframe" style="display:none;"></iframe>
```

3. Ajoutez un script JavaScript pour gérer la redirection après soumission:

```javascript
document.getElementById('contact-form').addEventListener('submit', function(e) {
    // Attendre quelques secondes pour permettre la soumission
    setTimeout(function() {
        // Afficher un message de remerciement
        document.getElementById('form-container').style.display = 'none';
        document.getElementById('success-container').style.display = 'block';
        
        // Rediriger vers votre site personnel après quelques secondes
        setTimeout(function() {
            window.location.href = "https://votre-site-personnel.com";
        }, 3000);
    }, 1000);
});
```

### Utilisation de localStorage pour Stockage Temporaire

Si vous ne souhaitez pas utiliser une base de données externe, vous pouvez stocker temporairement les informations dans localStorage et les envoyer par email:

```javascript
document.getElementById('contact-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Collecter les données
    const formData = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        message: document.getElementById('message').value,
        latitude: document.getElementById('latitude').value,
        longitude: document.getElementById('longitude').value,
        date: new Date().toISOString()
    };
    
    // Stocker dans localStorage
    const scans = JSON.parse(localStorage.getItem('nfcScans') || '[]');
    scans.push(formData);
    localStorage.setItem('nfcScans', JSON.stringify(scans));
    
    // Afficher confirmation et rediriger
    document.getElementById('form-container').style.display = 'none';
    document.getElementById('success-container').style.display = 'block';
    
    setTimeout(function() {
        window.location.href = "https://votre-site-personnel.com";
    }, 3000);
});
```

## Configuration de Votre Domaine

Puisque vous possédez déjà un nom de domaine, vous pouvez l'utiliser avec les services d'hébergement gratuits:

1. Accédez au panneau de gestion de votre domaine chez votre registrar
2. Créez un sous-domaine (par exemple, nfc.votredomaine.com)
3. Pointez ce sous-domaine vers votre hébergement gratuit:
   - Chez InfinityFree, ajoutez votre domaine dans le panneau de contrôle
   - Mettez à jour les enregistrements DNS (généralement des CNAME ou des enregistrements A)
   - Suivez les instructions spécifiques de l'hébergeur gratuit choisi

## Économie sur la Programmation de la Puce

Pour programmer votre puce Vivokey Spark 2, vous n'avez pas besoin d'acheter d'équipement spécial:

1. Utilisez votre smartphone personnel (Android ou iPhone récent)
2. Téléchargez une application gratuite comme NFC Tools (Android/iOS) ou NXP TagWriter
3. Suivez les instructions dans le guide de programmation pour écrire l'URL sur votre puce

## Résumé de la Solution Gratuite

1. **Hébergement**: InfinityFree, AwardSpace, ou Freehostia (tous gratuits, sans publicité)
2. **Stockage de données**: MySQL gratuit, Google Sheets, ou localStorage
3. **Domaine**: Votre domaine existant (créez un sous-domaine dédié)
4. **Programmation NFC**: Applications mobiles gratuites (NFC Tools, NXP TagWriter)

Cette solution vous permet de mettre en place l'ensemble du système sans aucun coût supplémentaire, tout en utilisant votre nom de domaine existant pour une expérience professionnelle.